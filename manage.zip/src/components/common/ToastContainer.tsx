import React from 'react';
import { useApp } from '../../context/AppContext';

export const ToastContainer: React.FC = () => {
  const { toasts, removeToast } = useApp();

  if (toasts.length === 0) return null;

  return (
    <div className="fixed bottom-5 right-5 z-50 flex flex-col gap-2 max-w-sm pointer-events-none">
      {toasts.map((toast) => (
        <div
          key={toast.id}
          className="pointer-events-auto bg-[#213145] text-white p-3.5 rounded-xl shadow-xl border border-white/10 flex items-start gap-3 animate-in fade-in slide-in-from-bottom-2 duration-150"
        >
          <span
            className={`material-symbols-outlined text-[18px] shrink-0 mt-0.5 ${
              toast.type === 'success'
                ? 'text-[#6cf8bb]'
                : toast.type === 'error'
                ? 'text-[#ffdad6]'
                : 'text-[#c3c0ff]'
            }`}
          >
            {toast.type === 'success'
              ? 'check_circle'
              : toast.type === 'error'
              ? 'error'
              : 'info'}
          </span>
          <div className="flex-1 min-w-0">
            <h5 className="text-xs font-bold leading-tight">{toast.title}</h5>
            {toast.message && (
              <p className="text-[11px] text-[#c7c4d8] mt-0.5 leading-snug">
                {toast.message}
              </p>
            )}
          </div>
          <button
            onClick={() => removeToast(toast.id)}
            className="text-[#c7c4d8] hover:text-white shrink-0 p-0.5 cursor-pointer"
          >
            <span className="material-symbols-outlined text-[14px]">close</span>
          </button>
        </div>
      ))}
    </div>
  );
};
