import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { TaskPriority, TaskStatus } from '../../types';

export const CreateItemModal: React.FC = () => {
  const {
    isCreateItemModalOpen,
    setIsCreateItemModalOpen,
    createItemDefaultTab,
    projects,
    teamMembers,
    addTask,
    addProject,
    addMilestone,
    addGoal,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'task' | 'project' | 'goal' | 'milestone'>('task');

  // Task form state
  const [taskTitle, setTaskTitle] = useState('');
  const [taskProject, setTaskProject] = useState('');
  const [taskPriority, setTaskPriority] = useState<TaskPriority>('high');
  const [taskStatus, setTaskStatus] = useState<TaskStatus>('todo');
  const [taskAssignee, setTaskAssignee] = useState('');
  const [taskDueDate, setTaskDueDate] = useState('');
  const [taskDesc, setTaskDesc] = useState('');

  // Project form state
  const [projName, setProjName] = useState('');
  const [projCategory, setProjCategory] = useState('Web & Mobile Application');
  const [projPriority, setProjPriority] = useState<TaskPriority>('high');
  const [projDeadline, setProjDeadline] = useState('');
  const [projDesc, setProjDesc] = useState('');

  // Milestone form state
  const [msTitle, setMsTitle] = useState('');
  const [msProject, setMsProject] = useState('');
  const [msDeadline, setMsDeadline] = useState('');
  const [msDesc, setMsDesc] = useState('');

  // Goal form state
  const [goalTitle, setGoalTitle] = useState('');
  const [goalKeyResult, setGoalKeyResult] = useState('');
  const [goalQuarter, setGoalQuarter] = useState('Q3 2024 (Jul - Oct)');

  useEffect(() => {
    if (isCreateItemModalOpen) {
      setActiveTab(createItemDefaultTab);
      if (projects.length > 0) {
        setTaskProject(projects[0].id);
        setMsProject(projects[0].id);
      }
      if (teamMembers.length > 0) {
        setTaskAssignee(teamMembers[0].id);
      }
    }
  }, [isCreateItemModalOpen, createItemDefaultTab, projects, teamMembers]);

  if (!isCreateItemModalOpen) return null;

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!taskTitle.trim()) return;

    addTask({
      title: taskTitle.trim(),
      projectId: taskProject || projects[0]?.id,
      priority: taskPriority,
      status: taskStatus,
      assigneeId: taskAssignee || teamMembers[0]?.id,
      dueDate: taskDueDate || '2024-10-01',
      dueLabel: taskDueDate ? `Due ${taskDueDate}` : 'Due Oct 1',
      description: taskDesc.trim(),
    });

    setTaskTitle('');
    setTaskDesc('');
    setIsCreateItemModalOpen(false);
  };

  const handleCreateProject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!projName.trim()) return;

    addProject({
      name: projName.trim(),
      category: projCategory,
      priority: projPriority,
      deadline: projDeadline || '2024-11-15',
      deadlineLabel: projDeadline ? `Due ${projDeadline}` : 'Due Nov 15',
      description: projDesc.trim(),
    });

    setProjName('');
    setProjDesc('');
    setIsCreateItemModalOpen(false);
  };

  const handleCreateMilestone = (e: React.FormEvent) => {
    e.preventDefault();
    if (!msTitle.trim()) return;

    addMilestone({
      title: msTitle.trim(),
      projectId: msProject || projects[0]?.id,
      deadline: msDeadline || '2024-10-15',
      description: msDesc.trim(),
    });

    setMsTitle('');
    setMsDesc('');
    setIsCreateItemModalOpen(false);
  };

  const handleCreateGoal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!goalTitle.trim()) return;

    addGoal({
      title: goalTitle.trim(),
      keyResult: goalKeyResult.trim(),
      quarter: goalQuarter,
    });

    setGoalTitle('');
    setGoalKeyResult('');
    setIsCreateItemModalOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs">
      <div
        className="w-full max-w-xl bg-white rounded-xl shadow-2xl border border-[#c7c4d8]/40 overflow-hidden animate-in fade-in zoom-in-95 duration-150 flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header with tabs */}
        <div className="p-4 border-b border-[#c7c4d8]/25 bg-[#f8f9ff]">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-headline font-bold text-base text-[#0b1c30]">
              Create New Item
            </h3>
            <button
              onClick={() => setIsCreateItemModalOpen(false)}
              className="text-[#777587] hover:text-[#0b1c30] p-1 rounded-lg"
            >
              <span className="material-symbols-outlined text-[18px]">close</span>
            </button>
          </div>

          <div className="flex bg-[#e5eeff] p-1 rounded-lg gap-1">
            <button
              type="button"
              onClick={() => setActiveTab('task')}
              className={`flex-1 py-1.5 px-3 rounded-md text-xs font-semibold transition-all ${
                activeTab === 'task'
                  ? 'bg-white text-[#3525cd] shadow-xs'
                  : 'text-[#464555] hover:text-[#0b1c30]'
              }`}
            >
              Task
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('project')}
              className={`flex-1 py-1.5 px-3 rounded-md text-xs font-semibold transition-all ${
                activeTab === 'project'
                  ? 'bg-white text-[#3525cd] shadow-xs'
                  : 'text-[#464555] hover:text-[#0b1c30]'
              }`}
            >
              Project
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('milestone')}
              className={`flex-1 py-1.5 px-3 rounded-md text-xs font-semibold transition-all ${
                activeTab === 'milestone'
                  ? 'bg-white text-[#3525cd] shadow-xs'
                  : 'text-[#464555] hover:text-[#0b1c30]'
              }`}
            >
              Milestone
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('goal')}
              className={`flex-1 py-1.5 px-3 rounded-md text-xs font-semibold transition-all ${
                activeTab === 'goal'
                  ? 'bg-white text-[#3525cd] shadow-xs'
                  : 'text-[#464555] hover:text-[#0b1c30]'
              }`}
            >
              Company Goal
            </button>
          </div>
        </div>

        {/* Form Body */}
        <div className="p-5 overflow-y-auto custom-scrollbar flex-1 text-xs">
          {activeTab === 'task' && (
            <form onSubmit={handleCreateTask} className="space-y-4">
              <div>
                <label className="block font-semibold text-[#0b1c30] mb-1">Task Title *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Implement OAuth Single Sign-On"
                  value={taskTitle}
                  onChange={(e) => setTaskTitle(e.target.value)}
                  className="w-full px-3 py-2 border border-[#c7c4d8]/60 rounded-lg focus:border-[#3525cd] focus:ring-1 focus:ring-[#3525cd]/20 outline-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-[#0b1c30] mb-1">Project</label>
                  <select
                    value={taskProject}
                    onChange={(e) => setTaskProject(e.target.value)}
                    className="w-full px-3 py-2 border border-[#c7c4d8]/60 rounded-lg bg-white outline-none"
                  >
                    {projects.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name} ({p.code})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-[#0b1c30] mb-1">Assignee</label>
                  <select
                    value={taskAssignee}
                    onChange={(e) => setTaskAssignee(e.target.value)}
                    className="w-full px-3 py-2 border border-[#c7c4d8]/60 rounded-lg bg-white outline-none"
                  >
                    {teamMembers.map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.name} ({m.role})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-[#0b1c30] mb-1">Priority</label>
                  <select
                    value={taskPriority}
                    onChange={(e) => setTaskPriority(e.target.value as TaskPriority)}
                    className="w-full px-3 py-2 border border-[#c7c4d8]/60 rounded-lg bg-white outline-none"
                  >
                    <option value="urgent">Urgent</option>
                    <option value="high">High</option>
                    <option value="medium">Medium</option>
                    <option value="low">Low</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-[#0b1c30] mb-1">Status</label>
                  <select
                    value={taskStatus}
                    onChange={(e) => setTaskStatus(e.target.value as TaskStatus)}
                    className="w-full px-3 py-2 border border-[#c7c4d8]/60 rounded-lg bg-white outline-none"
                  >
                    <option value="backlog">Backlog</option>
                    <option value="todo">To Do</option>
                    <option value="in_progress">In Progress</option>
                    <option value="review">Review</option>
                    <option value="done">Done</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-[#0b1c30] mb-1">Due Date</label>
                  <input
                    type="date"
                    value={taskDueDate}
                    onChange={(e) => setTaskDueDate(e.target.value)}
                    className="w-full px-3 py-2 border border-[#c7c4d8]/60 rounded-lg bg-white outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-[#0b1c30] mb-1">Description</label>
                <textarea
                  rows={3}
                  placeholder="Provide technical context, acceptance criteria, or dependencies..."
                  value={taskDesc}
                  onChange={(e) => setTaskDesc(e.target.value)}
                  className="w-full px-3 py-2 border border-[#c7c4d8]/60 rounded-lg focus:border-[#3525cd] focus:ring-1 focus:ring-[#3525cd]/20 outline-none"
                />
              </div>

              <div className="pt-3 border-t border-[#c7c4d8]/20 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsCreateItemModalOpen(false)}
                  className="px-4 py-2 border border-[#c7c4d8]/50 rounded-lg hover:bg-[#eff4ff] text-[#0b1c30] font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#4f46e5] hover:bg-[#3525cd] text-white rounded-lg font-semibold shadow-xs"
                >
                  Create Task
                </button>
              </div>
            </form>
          )}

          {activeTab === 'project' && (
            <form onSubmit={handleCreateProject} className="space-y-4">
              <div>
                <label className="block font-semibold text-[#0b1c30] mb-1">Project Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Real-Time Collaboration Canvas"
                  value={projName}
                  onChange={(e) => setProjName(e.target.value)}
                  className="w-full px-3 py-2 border border-[#c7c4d8]/60 rounded-lg focus:border-[#3525cd] focus:ring-1 focus:ring-[#3525cd]/20 outline-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-[#0b1c30] mb-1">Category</label>
                  <input
                    type="text"
                    value={projCategory}
                    onChange={(e) => setProjCategory(e.target.value)}
                    className="w-full px-3 py-2 border border-[#c7c4d8]/60 rounded-lg outline-none"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-[#0b1c30] mb-1">Priority</label>
                  <select
                    value={projPriority}
                    onChange={(e) => setProjPriority(e.target.value as TaskPriority)}
                    className="w-full px-3 py-2 border border-[#c7c4d8]/60 rounded-lg bg-white outline-none"
                  >
                    <option value="urgent">Urgent</option>
                    <option value="high">High</option>
                    <option value="medium">Medium</option>
                    <option value="low">Low</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-[#0b1c30] mb-1">Target Deadline</label>
                  <input
                    type="date"
                    value={projDeadline}
                    onChange={(e) => setProjDeadline(e.target.value)}
                    className="w-full px-3 py-2 border border-[#c7c4d8]/60 rounded-lg bg-white outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-[#0b1c30] mb-1">Project Overview</label>
                <textarea
                  rows={3}
                  placeholder="Summarize the core objective, target users, and expected milestones..."
                  value={projDesc}
                  onChange={(e) => setProjDesc(e.target.value)}
                  className="w-full px-3 py-2 border border-[#c7c4d8]/60 rounded-lg focus:border-[#3525cd] outline-none"
                />
              </div>

              <div className="pt-3 border-t border-[#c7c4d8]/20 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsCreateItemModalOpen(false)}
                  className="px-4 py-2 border border-[#c7c4d8]/50 rounded-lg hover:bg-[#eff4ff] text-[#0b1c30] font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#4f46e5] hover:bg-[#3525cd] text-white rounded-lg font-semibold shadow-xs"
                >
                  Launch Project
                </button>
              </div>
            </form>
          )}

          {activeTab === 'milestone' && (
            <form onSubmit={handleCreateMilestone} className="space-y-4">
              <div>
                <label className="block font-semibold text-[#0b1c30] mb-1">Milestone Title *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Beta Testing Kickoff & Security Audit"
                  value={msTitle}
                  onChange={(e) => setMsTitle(e.target.value)}
                  className="w-full px-3 py-2 border border-[#c7c4d8]/60 rounded-lg outline-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-[#0b1c30] mb-1">Parent Project</label>
                  <select
                    value={msProject}
                    onChange={(e) => setMsProject(e.target.value)}
                    className="w-full px-3 py-2 border border-[#c7c4d8]/60 rounded-lg bg-white outline-none"
                  >
                    {projects.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-[#0b1c30] mb-1">Target Deadline</label>
                  <input
                    type="date"
                    value={msDeadline}
                    onChange={(e) => setMsDeadline(e.target.value)}
                    className="w-full px-3 py-2 border border-[#c7c4d8]/60 rounded-lg bg-white outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-[#0b1c30] mb-1">Description & Deliverables</label>
                <textarea
                  rows={3}
                  placeholder="What key outcomes mark this milestone as complete?"
                  value={msDesc}
                  onChange={(e) => setMsDesc(e.target.value)}
                  className="w-full px-3 py-2 border border-[#c7c4d8]/60 rounded-lg outline-none"
                />
              </div>

              <div className="pt-3 border-t border-[#c7c4d8]/20 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsCreateItemModalOpen(false)}
                  className="px-4 py-2 border border-[#c7c4d8]/50 rounded-lg hover:bg-[#eff4ff] text-[#0b1c30] font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#006c49] hover:bg-[#005236] text-white rounded-lg font-semibold shadow-xs"
                >
                  Add Milestone
                </button>
              </div>
            </form>
          )}

          {activeTab === 'goal' && (
            <form onSubmit={handleCreateGoal} className="space-y-4">
              <div>
                <label className="block font-semibold text-[#0b1c30] mb-1">Company Goal *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Achieve $500k ARR & 50 Enterprise Clients"
                  value={goalTitle}
                  onChange={(e) => setGoalTitle(e.target.value)}
                  className="w-full px-3 py-2 border border-[#c7c4d8]/60 rounded-lg outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold text-[#0b1c30] mb-1">Key Result (Measurable Target) *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. 100 enterprise pilots with 85% conversion to paid"
                  value={goalKeyResult}
                  onChange={(e) => setGoalKeyResult(e.target.value)}
                  className="w-full px-3 py-2 border border-[#c7c4d8]/60 rounded-lg outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold text-[#0b1c30] mb-1">Target Quarter</label>
                <select
                  value={goalQuarter}
                  onChange={(e) => setGoalQuarter(e.target.value)}
                  className="w-full px-3 py-2 border border-[#c7c4d8]/60 rounded-lg bg-white outline-none"
                >
                  <option value="Q3 2024 (Jul - Oct)">Q3 2024 (Jul - Oct)</option>
                  <option value="Q4 2024 (Nov - Jan)">Q4 2024 (Nov - Jan)</option>
                  <option value="Q1 2025 (Feb - Apr)">Q1 2025 (Feb - Apr)</option>
                </select>
              </div>

              <div className="pt-3 border-t border-[#c7c4d8]/20 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsCreateItemModalOpen(false)}
                  className="px-4 py-2 border border-[#c7c4d8]/50 rounded-lg hover:bg-[#eff4ff] text-[#0b1c30] font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#3525cd] hover:bg-[#213145] text-white rounded-lg font-semibold shadow-xs"
                >
                  Establish Goal
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
