import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TaskPriority, TaskStatus } from '../../types';

export const TaskDetailsModal: React.FC = () => {
  const {
    selectedTaskId,
    closeTaskDetails,
    tasks,
    updateTaskStatus,
    toggleTaskChecklist,
    addTaskComment,
    teamMembers,
  } = useApp();

  const [newComment, setNewComment] = useState('');
  const [newChecklistText, setNewChecklistText] = useState('');

  if (!selectedTaskId) return null;

  const task = tasks.find((t) => t.id === selectedTaskId);
  if (!task) return null;

  const completedChecklistCount = task.checklist.filter((c) => c.completed).length;
  const checklistPercent =
    task.checklist.length > 0
      ? Math.round((completedChecklistCount / task.checklist.length) * 100)
      : 0;

  const handlePostComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim()) return;
    addTaskComment(task.id, newComment.trim());
    setNewComment('');
  };

  const handleAddChecklistItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newChecklistText.trim()) return;
    // We can append a checklist item to the task
    task.checklist.push({
      id: `cl-${Date.now()}`,
      title: newChecklistText.trim(),
      completed: false,
    });
    setNewChecklistText('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs">
      <div
        className="w-full max-w-2xl bg-white rounded-xl shadow-2xl border border-[#c7c4d8]/40 overflow-hidden animate-in fade-in zoom-in-95 duration-150 flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Top Header */}
        <div className="p-4 border-b border-[#c7c4d8]/25 bg-[#f8f9ff] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="font-mono text-xs font-bold text-[#3525cd] bg-[#e2dfff] px-2 py-0.5 rounded border border-[#3525cd]/20">
              {task.code}
            </span>
            <span className="text-xs text-[#777587]">in {task.projectName}</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={closeTaskDetails}
              className="text-[#777587] hover:text-[#0b1c30] p-1.5 rounded-lg hover:bg-white"
            >
              <span className="material-symbols-outlined text-[18px]">close</span>
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-5 overflow-y-auto custom-scrollbar flex-1 space-y-5 text-xs">
          {/* Title & Priority Tag */}
          <div>
            <div className="flex items-start justify-between gap-3">
              <h2 className="font-headline font-bold text-lg text-[#0b1c30] leading-snug">
                {task.title}
              </h2>
              <span
                className={`px-2.5 py-0.5 rounded-full text-xs font-bold uppercase shrink-0 ${
                  task.priority === 'urgent'
                    ? 'bg-[#ffdad6] text-[#ba1a1a] border border-[#ba1a1a]/20'
                    : task.priority === 'high'
                    ? 'bg-[#ffddb8] text-[#684000]'
                    : 'bg-[#e5eeff] text-[#464555]'
                }`}
              >
                ● {task.priority}
              </span>
            </div>

            {task.milestoneName && (
              <div className="inline-flex items-center gap-1.5 px-2 py-0.5 mt-2 rounded bg-[#f8f9ff] text-[#3525cd] font-semibold border border-[#c7c4d8]/30">
                <span className="material-symbols-outlined text-[14px]">flag</span>
                <span>{task.milestoneName}</span>
              </div>
            )}
          </div>

          {/* Quick Properties Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3 rounded-lg bg-[#eff4ff]/60 border border-[#c7c4d8]/30">
            <div>
              <span className="text-[10px] text-[#777587] font-semibold uppercase block mb-1">Status</span>
              <select
                value={task.status}
                onChange={(e) => updateTaskStatus(task.id, e.target.value as TaskStatus)}
                className="w-full bg-white border border-[#c7c4d8]/50 rounded px-2 py-1 text-xs font-semibold text-[#0b1c30] outline-none"
              >
                <option value="backlog">Backlog</option>
                <option value="todo">To Do</option>
                <option value="in_progress">In Progress</option>
                <option value="review">Review</option>
                <option value="done">Done</option>
              </select>
            </div>

            <div>
              <span className="text-[10px] text-[#777587] font-semibold uppercase block mb-1">Assignee</span>
              <div className="flex items-center gap-1.5 py-1">
                <img
                  src={task.assigneeAvatar}
                  alt={task.assigneeName}
                  className="w-5 h-5 rounded-full object-cover"
                />
                <span className="font-semibold text-[#0b1c30] truncate">{task.assigneeName}</span>
              </div>
            </div>

            <div>
              <span className="text-[10px] text-[#777587] font-semibold uppercase block mb-1">Due Date</span>
              <span className="font-semibold text-[#ba1a1a] flex items-center gap-1 py-1">
                <span className="material-symbols-outlined text-[14px]">event</span>
                {task.dueLabel || task.dueDate}
              </span>
            </div>

            <div>
              <span className="text-[10px] text-[#777587] font-semibold uppercase block mb-1">Subtasks</span>
              <span className="font-semibold text-[#0b1c30] py-1 block">
                {completedChecklistCount}/{task.checklist.length} completed
              </span>
            </div>
          </div>

          {/* Description */}
          <div>
            <h4 className="font-bold text-[#0b1c30] text-xs uppercase tracking-wider mb-1.5">
              Description
            </h4>
            <p className="text-xs text-[#464555] leading-relaxed bg-[#f8f9ff] p-3 rounded-lg border border-[#c7c4d8]/20">
              {task.description || 'No extended description provided.'}
            </p>
          </div>

          {/* Checklist */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h4 className="font-bold text-[#0b1c30] text-xs uppercase tracking-wider flex items-center gap-1.5">
                <span className="material-symbols-outlined text-[16px] text-[#3525cd]">check_box</span>
                Checklist ({completedChecklistCount}/{task.checklist.length})
              </h4>
              <span className="font-mono text-xs font-bold text-[#3525cd]">
                {checklistPercent}%
              </span>
            </div>

            {/* Checklist progress bar */}
            <div className="w-full bg-[#e5eeff] rounded-full h-1.5 overflow-hidden mb-3">
              <div
                className="bg-[#3525cd] h-1.5 rounded-full transition-all duration-300"
                style={{ width: `${checklistPercent}%` }}
              />
            </div>

            {/* Checklist items */}
            <div className="space-y-1.5">
              {task.checklist.map((item) => (
                <div
                  key={item.id}
                  onClick={() => toggleTaskChecklist(task.id, item.id)}
                  className="flex items-center gap-2.5 p-2 rounded-lg hover:bg-[#eff4ff] cursor-pointer transition-colors"
                >
                  <input
                    type="checkbox"
                    checked={item.completed}
                    onChange={() => {}}
                    className="w-4 h-4 rounded text-[#3525cd] focus:ring-[#3525cd] border-[#c7c4d8]"
                  />
                  <span
                    className={`text-xs ${
                      item.completed
                        ? 'line-through text-[#777587]'
                        : 'text-[#0b1c30] font-medium'
                    }`}
                  >
                    {item.title}
                  </span>
                </div>
              ))}
            </div>

            {/* Add checklist item */}
            <form onSubmit={handleAddChecklistItem} className="mt-2 flex gap-2">
              <input
                type="text"
                placeholder="+ Add a checklist subtask..."
                value={newChecklistText}
                onChange={(e) => setNewChecklistText(e.target.value)}
                className="flex-1 px-3 py-1.5 border border-[#c7c4d8]/50 rounded-lg text-xs outline-none"
              />
              <button
                type="submit"
                className="px-3 py-1.5 bg-[#eff4ff] hover:bg-[#dce9ff] text-[#3525cd] font-semibold rounded-lg text-xs"
              >
                Add
              </button>
            </form>
          </div>

          {/* Activity & Comments Thread */}
          <div className="border-t border-[#c7c4d8]/20 pt-4">
            <h4 className="font-bold text-[#0b1c30] text-xs uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[16px] text-[#777587]">chat</span>
              Comments &amp; Activity ({task.comments.length})
            </h4>

            {/* Existing comments */}
            <div className="space-y-3 mb-4">
              {task.comments.length === 0 ? (
                <p className="text-xs text-[#777587] italic">No comments yet. Be the first to leave an update.</p>
              ) : (
                task.comments.map((comment) => (
                  <div key={comment.id} className="flex gap-2.5 items-start">
                    <img
                      src={comment.authorAvatar}
                      alt={comment.authorName}
                      className="w-6 h-6 rounded-full object-cover shrink-0 mt-0.5"
                    />
                    <div className="flex-1 bg-[#f8f9ff] p-2.5 rounded-lg border border-[#c7c4d8]/20">
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-bold text-[#0b1c30]">{comment.authorName}</span>
                        <span className="text-[10px] text-[#777587] font-mono">{comment.createdAt}</span>
                      </div>
                      <p className="text-xs text-[#464555]">{comment.content}</p>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Comment form */}
            <form onSubmit={handlePostComment} className="flex gap-2 items-end">
              <div className="flex-1">
                <textarea
                  rows={2}
                  placeholder="Write a comment or mention @teammate..."
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  className="w-full px-3 py-2 border border-[#c7c4d8]/60 rounded-lg text-xs outline-none focus:border-[#3525cd]"
                />
              </div>
              <button
                type="submit"
                disabled={!newComment.trim()}
                className="px-4 py-2 bg-[#4f46e5] hover:bg-[#3525cd] disabled:opacity-50 text-white font-semibold rounded-lg text-xs shadow-xs cursor-pointer"
              >
                Send
              </button>
            </form>
          </div>
        </div>

        {/* Footer actions */}
        <div className="p-3 border-t border-[#c7c4d8]/20 bg-[#f8f9ff] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                const nextStatus: TaskStatus = task.status === 'done' ? 'todo' : 'done';
                updateTaskStatus(task.id, nextStatus);
              }}
              className={`px-3 py-1.5 rounded-lg font-semibold text-xs flex items-center gap-1.5 transition-colors ${
                task.status === 'done'
                  ? 'bg-[#e5eeff] text-[#464555] hover:bg-[#dce9ff]'
                  : 'bg-[#6cf8bb]/30 text-[#00714d] hover:bg-[#6cf8bb]/50'
              }`}
            >
              <span className="material-symbols-outlined text-[16px]">
                {task.status === 'done' ? 'replay' : 'check_circle'}
              </span>
              <span>{task.status === 'done' ? 'Reopen Task' : 'Mark as Done'}</span>
            </button>
          </div>

          <button
            onClick={closeTaskDetails}
            className="px-4 py-1.5 bg-[#eff4ff] hover:bg-[#dce9ff] text-[#0b1c30] font-semibold rounded-lg text-xs"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
