import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';

export const NotificationsView: React.FC = () => {
  const {
    notifications,
    markNotificationAsRead,
    markAllNotificationsAsRead,
    setCurrentView,
    openTaskDetails,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'all' | 'unread' | 'alerts'>('all');

  const unreadCount = notifications.filter((n) => !n.read).length;

  const filteredNotifications = notifications.filter((n) => {
    if (activeTab === 'unread') return !n.read;
    if (activeTab === 'alerts') return n.type === 'deadline' || n.type === 'assignment';
    return true;
  });

  const getNotifIcon = (type: string) => {
    switch (type) {
      case 'assignment':
        return { icon: 'assignment_ind', color: 'text-[#3525cd] bg-[#e2dfff]' };
      case 'deadline':
        return { icon: 'warning', color: 'text-[#ba1a1a] bg-[#ffdad6]' };
      case 'activity':
        return { icon: 'task_alt', color: 'text-[#006c49] bg-[#6cf8bb]/30' };
      default:
        return { icon: 'notifications', color: 'text-[#4f46e5] bg-[#eff4ff]' };
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-in fade-in duration-150">
      {/* Header & Mark All as Read */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <h1 className="font-headline font-bold text-xl text-[#0b1c30]">
              Notifications &amp; Activity Stream
            </h1>
            {unreadCount > 0 && (
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#4f46e5] text-white">
                {unreadCount} Unread
              </span>
            )}
          </div>
          <p className="text-xs text-[#777587]">
            Sprint updates, milestone deliverables, task completions, and alerts
          </p>
        </div>

        {unreadCount > 0 && (
          <button
            onClick={markAllNotificationsAsRead}
            className="text-xs font-semibold text-[#3525cd] hover:underline flex items-center gap-1.5 self-start sm:self-auto cursor-pointer"
          >
            <span className="material-symbols-outlined text-[16px]">done_all</span>
            <span>Mark All as Read</span>
          </button>
        )}
      </div>

      {/* Filter Tabs */}
      <div className="bg-white p-1.5 rounded-xl border border-[#c7c4d8]/40 shadow-2xs flex items-center gap-1 max-w-sm">
        <button
          onClick={() => setActiveTab('all')}
          className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-semibold transition-all ${
            activeTab === 'all'
              ? 'bg-[#3525cd] text-white shadow-2xs'
              : 'text-[#464555] hover:text-[#0b1c30]'
          }`}
        >
          All ({notifications.length})
        </button>
        <button
          onClick={() => setActiveTab('unread')}
          className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-semibold transition-all ${
            activeTab === 'unread'
              ? 'bg-[#3525cd] text-white shadow-2xs'
              : 'text-[#464555] hover:text-[#0b1c30]'
          }`}
        >
          Unread ({unreadCount})
        </button>
        <button
          onClick={() => setActiveTab('alerts')}
          className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-semibold transition-all ${
            activeTab === 'alerts'
              ? 'bg-[#3525cd] text-white shadow-2xs'
              : 'text-[#464555] hover:text-[#0b1c30]'
          }`}
        >
          Alerts
        </button>
      </div>

      {/* Notifications List */}
      <div className="bg-white rounded-xl border border-[#c7c4d8]/40 divide-y divide-[#c7c4d8]/15 overflow-hidden shadow-xs">
        {filteredNotifications.length === 0 ? (
          <div className="p-8 text-center text-xs text-[#777587]">
            <span className="material-symbols-outlined text-3xl mb-1 text-[#c7c4d8] block">
              notifications_off
            </span>
            No notifications in this category.
          </div>
        ) : (
          filteredNotifications.map((n) => {
            const { icon, color } = getNotifIcon(n.type);

            return (
              <div
                key={n.id}
                onClick={() => {
                  markNotificationAsRead(n.id);
                  if (n.linkAction?.view) {
                    setCurrentView(n.linkAction.view);
                    if (n.linkAction.id && n.linkAction.view === 'tasks') {
                      openTaskDetails(n.linkAction.id);
                    }
                  }
                }}
                className={`p-4 flex items-start gap-4 hover:bg-[#f8f9ff] transition-colors cursor-pointer ${
                  !n.read ? 'bg-[#eff4ff]/30' : ''
                }`}
              >
                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${color}`}
                >
                  <span className="material-symbols-outlined text-[18px]">{icon}</span>
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <h4
                      className={`text-xs ${
                        !n.read ? 'font-bold text-[#0b1c30]' : 'font-semibold text-[#464555]'
                      }`}
                    >
                      {n.title}
                    </h4>
                    <span className="text-[10px] text-[#777587] font-mono shrink-0">
                      {n.timestamp}
                    </span>
                  </div>

                  <p className="text-xs text-[#464555] leading-relaxed mb-2">
                    {n.description}
                  </p>

                  <div className="flex items-center justify-between">
                    <span className="text-[10px] uppercase font-bold tracking-wider text-[#777587] bg-[#f8f9ff] px-2 py-0.5 rounded border border-[#c7c4d8]/20">
                      {n.type}
                    </span>

                    {!n.read && (
                      <span className="text-[11px] font-semibold text-[#3525cd] hover:underline">
                        Mark as read →
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
