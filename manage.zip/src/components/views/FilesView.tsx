import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';

export const FilesView: React.FC = () => {
  const { files, projects, addFile, addToast } = useApp();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [search, setSearch] = useState('');
  const [isDragging, setIsDragging] = useState(false);

  const categories = ['All', 'Architecture', 'Design Specs', 'Contracts', 'Sprint Assets'];

  const filteredFiles = files.filter((f) => {
    const matchesCat =
      selectedCategory === 'all' || f.category.toLowerCase() === selectedCategory.toLowerCase();
    const matchesSearch =
      f.name.toLowerCase().includes(search.toLowerCase()) ||
      f.projectName.toLowerCase().includes(search.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const handleSimulatedUpload = (name: string, size: string) => {
    addFile({
      name,
      size,
      projectId: projects[0]?.id,
      category: 'Sprint Assets',
      type: name.endsWith('.pdf') ? 'pdf' : name.endsWith('.fig') ? 'figma' : 'image',
    });
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const droppedFile = e.dataTransfer.files[0];
      const sizeMb = (droppedFile.size / (1024 * 1024)).toFixed(1);
      handleSimulatedUpload(droppedFile.name, `${sizeMb} MB`);
    }
  };

  const handleDownload = (fileName: string) => {
    addToast({
      type: 'success',
      title: 'Download Started',
      message: `Downloading "${fileName}" to your local downloads folder.`,
    });
  };

  const getFileIcon = (type: string) => {
    switch (type) {
      case 'pdf':
        return { icon: 'picture_as_pdf', color: 'text-[#ba1a1a]' };
      case 'figma':
        return { icon: 'design_services', color: 'text-[#3525cd]' };
      case 'image':
        return { icon: 'image', color: 'text-[#006c49]' };
      case 'archive':
        return { icon: 'folder_zip', color: 'text-[#684000]' };
      default:
        return { icon: 'description', color: 'text-[#464555]' };
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-150">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-headline font-bold text-xl text-[#0b1c30]">
            Files &amp; Artifacts
          </h1>
          <p className="text-xs text-[#777587] mt-0.5">
            Architecture specs, Figma assets, and sprint release deliverables
          </p>
        </div>

        <label className="cursor-pointer bg-[#4f46e5] hover:bg-[#3525cd] text-white text-xs font-semibold px-4 py-2 rounded-lg flex items-center gap-1.5 shadow-xs transition-colors self-start sm:self-auto">
          <span className="material-symbols-outlined text-[16px]">cloud_upload</span>
          <span>Upload File</span>
          <input
            type="file"
            className="hidden"
            onChange={(e) => {
              if (e.target.files && e.target.files.length > 0) {
                const f = e.target.files[0];
                const sizeMb = (f.size / (1024 * 1024)).toFixed(1);
                handleSimulatedUpload(f.name, `${sizeMb} MB`);
              }
            }}
          />
        </label>
      </div>

      {/* Drag and Drop Zone */}
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleDrop}
        className={`border-2 border-dashed rounded-xl p-6 text-center transition-all bg-white ${
          isDragging
            ? 'border-[#3525cd] bg-[#eff4ff]/60 scale-[1.01]'
            : 'border-[#c7c4d8]/60 hover:border-[#3525cd]/40'
        }`}
      >
        <span className="material-symbols-outlined text-3xl text-[#3525cd] mb-1">
          upload_file
        </span>
        <h4 className="font-bold text-xs text-[#0b1c30]">
          Drag and drop files here, or browse from computer
        </h4>
        <p className="text-[11px] text-[#777587] mt-0.5">
          Supports PRDs, PDF specifications, Figma tokens, assets, and diagrams up to 100MB
        </p>
      </div>

      {/* Category Tabs & Search */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-white p-3 rounded-xl border border-[#c7c4d8]/40 shadow-2xs text-xs">
        <div className="flex items-center gap-1 overflow-x-auto w-full sm:w-auto">
          {categories.map((cat) => {
            const isSelected =
              (cat === 'All' && selectedCategory === 'all') ||
              cat.toLowerCase() === selectedCategory.toLowerCase();

            return (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat === 'All' ? 'all' : cat)}
                className={`px-3 py-1 rounded-md text-xs font-semibold whitespace-nowrap transition-all ${
                  isSelected
                    ? 'bg-[#3525cd] text-white shadow-2xs'
                    : 'text-[#464555] hover:text-[#0b1c30]'
                }`}
              >
                {cat}
              </button>
            );
          })}
        </div>

        <div className="relative w-full sm:w-64">
          <span className="material-symbols-outlined absolute left-2.5 top-2 text-[#777587] text-[16px]">
            search
          </span>
          <input
            type="text"
            placeholder="Search documents..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-8 pr-3 py-1 bg-[#f8f9ff] border border-[#c7c4d8]/50 rounded-lg text-xs text-[#0b1c30] outline-none"
          />
        </div>
      </div>

      {/* Files Table */}
      <div className="bg-white rounded-xl border border-[#c7c4d8]/40 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#eff4ff]/60 border-b border-[#c7c4d8]/20 text-[#777587] uppercase font-semibold">
              <tr>
                <th className="py-2.5 px-4">Document Name</th>
                <th className="py-2.5 px-3">Associated Project</th>
                <th className="py-2.5 px-3">Category</th>
                <th className="py-2.5 px-3">Size</th>
                <th className="py-2.5 px-3">Uploaded By</th>
                <th className="py-2.5 px-3">Modified</th>
                <th className="py-2.5 px-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#c7c4d8]/15">
              {filteredFiles.map((file) => {
                const { icon, color } = getFileIcon(file.type);

                return (
                  <tr key={file.id} className="hover:bg-[#f8f9ff] transition-colors">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2.5">
                        <span className={`material-symbols-outlined text-[20px] ${color}`}>
                          {icon}
                        </span>
                        <span className="font-semibold text-[#0b1c30]">{file.name}</span>
                      </div>
                    </td>
                    <td className="py-3 px-3 text-[#3525cd] font-medium">{file.projectName}</td>
                    <td className="py-3 px-3">
                      <span className="px-2 py-0.5 rounded bg-[#eff4ff] text-[#464555] text-[10px] font-semibold">
                        {file.category}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-[#777587] font-mono">{file.size}</td>
                    <td className="py-3 px-3 text-[#0b1c30] font-medium">{file.ownerName}</td>
                    <td className="py-3 px-3 text-[#777587]">{file.modifiedDate}</td>
                    <td className="py-3 px-3 text-right">
                      <button
                        onClick={() => handleDownload(file.name)}
                        className="text-[#3525cd] hover:underline font-semibold flex items-center gap-1 justify-end ml-auto"
                      >
                        <span className="material-symbols-outlined text-[15px]">download</span>
                        <span>Download</span>
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
