import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';

export const ProjectDetailsView: React.FC = () => {
  const {
    selectedProjectId,
    projects,
    tasks,
    milestones,
    teamMembers,
    openTaskDetails,
    setCurrentView,
    openCreateModal,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'tasks' | 'milestones' | 'team'>('tasks');

  const project = projects.find((p) => p.id === selectedProjectId) || projects[0];

  const projectTasks = tasks.filter((t) => t.projectId === project.id);
  const projectMilestones = milestones.filter((m) => m.projectId === project.id);
  const assignedMembers = teamMembers.filter((m) => project.assigneeIds.includes(m.id));

  const completedCount = projectTasks.filter((t) => t.status === 'done').length;
  const inProgressCount = projectTasks.filter((t) => t.status === 'in_progress').length;
  const todoCount = projectTasks.filter((t) => t.status === 'todo' || t.status === 'backlog').length;
  const reviewCount = projectTasks.filter((t) => t.status === 'review').length;

  return (
    <div className="space-y-6 animate-in fade-in duration-150">
      {/* Top Breadcrumb & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setCurrentView('projects')}
            className="text-xs text-[#3525cd] hover:underline flex items-center gap-1 font-semibold"
          >
            <span className="material-symbols-outlined text-[16px]">arrow_back</span>
            All Projects
          </button>
          <span className="text-[#c7c4d8]">/</span>
          <span className="font-mono text-xs font-bold text-[#3525cd] bg-[#e2dfff] px-2 py-0.5 rounded">
            {project.code}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setCurrentView('tasks')}
            className="px-3 py-1.5 bg-[#eff4ff] hover:bg-[#dce9ff] text-[#3525cd] text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <span className="material-symbols-outlined text-[16px]">view_kanban</span>
            <span>Open in Kanban</span>
          </button>
          <button
            onClick={() => openCreateModal('task')}
            className="px-3 py-1.5 bg-[#4f46e5] hover:bg-[#3525cd] text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
          >
            <span className="material-symbols-outlined text-[16px]">add</span>
            <span>+ Add Task</span>
          </button>
        </div>
      </div>

      {/* Project Overview Card */}
      <div className="bg-white rounded-xl border border-[#c7c4d8]/40 p-6 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-6">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <h1 className="font-headline font-bold text-2xl text-[#0b1c30]">
                {project.name}
              </h1>
              <span
                className={`text-[10px] font-bold uppercase px-2.5 py-0.5 rounded-full ${
                  project.priority === 'urgent'
                    ? 'bg-[#ffdad6] text-[#ba1a1a]'
                    : project.priority === 'high'
                    ? 'bg-[#ffddb8] text-[#684000]'
                    : 'bg-[#e5eeff] text-[#464555]'
                }`}
              >
                ● {project.priority} priority
              </span>
            </div>
            <p className="text-xs text-[#464555] leading-relaxed max-w-2xl">
              {project.description}
            </p>
          </div>

          {/* Quick Metrics stats */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 rounded-xl bg-[#f8f9ff] border border-[#c7c4d8]/30 min-w-80">
            <div>
              <span className="text-[10px] uppercase font-bold text-[#777587] block">Progress</span>
              <span className="text-xl font-headline font-bold text-[#006c49]">
                {project.progressPercentage}%
              </span>
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-[#777587] block">Deadline</span>
              <span className="text-sm font-bold text-[#ba1a1a]">
                {project.deadlineLabel || project.deadline}
              </span>
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-[#777587] block">Completed</span>
              <span className="text-sm font-bold text-[#0b1c30]">
                {completedCount} tasks
              </span>
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-[#777587] block">In Progress</span>
              <span className="text-sm font-bold text-[#3525cd]">
                {inProgressCount} tasks
              </span>
            </div>
          </div>
        </div>

        {/* Global Progress Bar */}
        <div className="mt-5 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-[#777587]">
              Sprint Completion: <strong className="text-[#0b1c30]">{completedCount}</strong> of <strong className="text-[#0b1c30]">{projectTasks.length}</strong> tasks logged
            </span>
            <span className="font-bold font-mono text-[#006c49]">{project.progressPercentage}%</span>
          </div>
          <div className="w-full bg-[#e5eeff] rounded-full h-2.5 overflow-hidden">
            <div
              className="bg-[#3525cd] h-2.5 rounded-full transition-all duration-300"
              style={{ width: `${project.progressPercentage}%` }}
            />
          </div>
        </div>
      </div>

      {/* Tabs Menu */}
      <div className="border-b border-[#c7c4d8]/30 flex items-center gap-6 text-xs font-semibold">
        <button
          onClick={() => setActiveTab('tasks')}
          className={`pb-3 flex items-center gap-2 border-b-2 transition-colors cursor-pointer ${
            activeTab === 'tasks'
              ? 'border-[#3525cd] text-[#3525cd]'
              : 'border-transparent text-[#777587] hover:text-[#0b1c30]'
          }`}
        >
          <span className="material-symbols-outlined text-[16px]">format_list_bulleted</span>
          <span>Tasks &amp; Deliverables ({projectTasks.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('milestones')}
          className={`pb-3 flex items-center gap-2 border-b-2 transition-colors cursor-pointer ${
            activeTab === 'milestones'
              ? 'border-[#3525cd] text-[#3525cd]'
              : 'border-transparent text-[#777587] hover:text-[#0b1c30]'
          }`}
        >
          <span className="material-symbols-outlined text-[16px]">flag</span>
          <span>Milestones Roadmap ({projectMilestones.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('team')}
          className={`pb-3 flex items-center gap-2 border-b-2 transition-colors cursor-pointer ${
            activeTab === 'team'
              ? 'border-[#3525cd] text-[#3525cd]'
              : 'border-transparent text-[#777587] hover:text-[#0b1c30]'
          }`}
        >
          <span className="material-symbols-outlined text-[16px]">group</span>
          <span>Assigned Team ({assignedMembers.length})</span>
        </button>
      </div>

      {/* Tab Content 1: Tasks List */}
      {activeTab === 'tasks' && (
        <div className="bg-white rounded-xl border border-[#c7c4d8]/40 overflow-hidden shadow-xs">
          <div className="p-4 border-b border-[#c7c4d8]/20 bg-[#f8f9ff] flex items-center justify-between">
            <div className="flex items-center gap-3 text-xs">
              <span className="font-bold text-[#0b1c30]">Task Breakdown</span>
              <span className="text-[#777587]">
                ({completedCount} Done, {inProgressCount} In Progress, {reviewCount} Review, {todoCount} Pending)
              </span>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#eff4ff]/60 border-b border-[#c7c4d8]/20 text-[#777587] uppercase font-semibold">
                <tr>
                  <th className="py-2.5 px-4">Task</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3">Priority</th>
                  <th className="py-2.5 px-3">Assignee</th>
                  <th className="py-2.5 px-3">Due Date</th>
                  <th className="py-2.5 px-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#c7c4d8]/15">
                {projectTasks.map((t) => (
                  <tr
                    key={t.id}
                    onClick={() => openTaskDetails(t.id)}
                    className="hover:bg-[#f8f9ff] cursor-pointer transition-colors"
                  >
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2.5">
                        <span className="font-mono text-[11px] font-bold text-[#3525cd] bg-[#e2dfff] px-1.5 py-0.5 rounded">
                          {t.code}
                        </span>
                        <span className="font-semibold text-[#0b1c30]">{t.title}</span>
                      </div>
                    </td>
                    <td className="py-3 px-3">
                      <span className="capitalize font-medium text-[#464555] px-2 py-0.5 rounded bg-[#eff4ff]">
                        {t.status.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="py-3 px-3">
                      <span
                        className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full ${
                          t.priority === 'urgent'
                            ? 'bg-[#ffdad6] text-[#ba1a1a]'
                            : t.priority === 'high'
                            ? 'bg-[#ffddb8] text-[#684000]'
                            : 'bg-[#e5eeff] text-[#464555]'
                        }`}
                      >
                        {t.priority}
                      </span>
                    </td>
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-1.5">
                        <img
                          src={t.assigneeAvatar}
                          alt={t.assigneeName}
                          className="w-5 h-5 rounded-full object-cover"
                        />
                        <span className="text-[#0b1c30]">{t.assigneeName}</span>
                      </div>
                    </td>
                    <td className="py-3 px-3 text-[#ba1a1a] font-medium">
                      {t.dueLabel || t.dueDate}
                    </td>
                    <td className="py-3 px-3 text-right">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          openTaskDetails(t.id);
                        }}
                        className="text-[#3525cd] hover:underline font-semibold"
                      >
                        Inspect →
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab Content 2: Milestones Roadmap */}
      {activeTab === 'milestones' && (
        <div className="space-y-4">
          {projectMilestones.map((ms) => (
            <div
              key={ms.id}
              className={`p-5 rounded-xl border bg-white shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4 ${
                ms.isAtRisk ? 'border-[#ba1a1a]/40 bg-[#fff8f7]' : 'border-[#c7c4d8]/40'
              }`}
            >
              <div className="flex items-start gap-4">
                <div
                  className={`w-9 h-9 rounded-full flex items-center justify-center font-bold text-sm shrink-0 ${
                    ms.status === 'completed'
                      ? 'bg-[#6cf8bb]/30 text-[#00714d]'
                      : ms.status === 'in_progress'
                      ? 'bg-[#3525cd] text-white'
                      : 'bg-[#e5eeff] text-[#777587]'
                  }`}
                >
                  {ms.status === 'completed' ? (
                    <span className="material-symbols-outlined text-[18px]">check</span>
                  ) : (
                    ms.number
                  )}
                </div>

                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-headline font-bold text-sm text-[#0b1c30]">{ms.title}</h3>
                    {ms.isAtRisk && (
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#ffdad6] text-[#ba1a1a]">
                        ⚠️ Risk Alert
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-[#464555] max-w-xl">{ms.description}</p>
                  {ms.riskDescription && (
                    <p className="text-[11px] font-medium text-[#ba1a1a] mt-1">
                      {ms.riskDescription}
                    </p>
                  )}
                  <span className="text-[11px] text-[#777587] block mt-1.5">
                    Lead: <strong>{ms.ownerName}</strong> ({ms.ownerRole}) • Target: {ms.deadline}
                  </span>
                </div>
              </div>

              <div className="flex flex-col items-end gap-2 shrink-0 min-w-36">
                <span className="font-mono font-bold text-sm text-[#006c49]">
                  {ms.progressPercentage}% Completed
                </span>
                <div className="w-36 bg-[#e5eeff] rounded-full h-1.5 overflow-hidden">
                  <div
                    className="bg-[#3525cd] h-1.5 rounded-full"
                    style={{ width: `${ms.progressPercentage}%` }}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tab Content 3: Team Assigned */}
      {activeTab === 'team' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {assignedMembers.map((m) => (
            <div
              key={m.id}
              className="p-4 rounded-xl border border-[#c7c4d8]/40 bg-white shadow-xs flex items-start gap-3"
            >
              <img
                src={m.avatar}
                alt={m.name}
                className="w-10 h-10 rounded-full object-cover border border-[#c7c4d8]/30"
              />
              <div className="flex-1 min-w-0 text-xs">
                <h4 className="font-bold text-[#0b1c30] truncate">{m.name}</h4>
                <p className="text-[11px] text-[#777587]">{m.role}</p>
                <div className="flex items-center gap-2 mt-2">
                  <span className="text-[10px] px-2 py-0.5 rounded bg-[#eff4ff] text-[#3525cd] font-semibold">
                    {m.assignedTasksCount} Active Tasks
                  </span>
                  <span className="text-[10px] text-[#006c49] font-medium">
                    {m.capacityPercentage}% Load
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
