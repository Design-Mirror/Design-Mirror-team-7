import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';

export const SettingsView: React.FC = () => {
  const { currentUser, addToast } = useApp();

  const [workspaceName, setWorkspaceName] = useState('Manage');
  const [workspaceDomain, setWorkspaceDomain] = useState('manage.dev');
  const [emailDigest, setEmailDigest] = useState(true);
  const [desktopPush, setDesktopPush] = useState(true);
  const [activeSettingsTab, setActiveSettingsTab] = useState<'general' | 'notifications' | 'members'>('general');

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    addToast({
      type: 'success',
      title: 'Preferences Saved',
      message: 'Workspace configurations updated successfully.',
    });
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-in fade-in duration-150">
      {/* Header */}
      <div>
        <h1 className="font-headline font-bold text-xl text-[#0b1c30]">
          Workspace Settings
        </h1>
        <p className="text-xs text-[#777587] mt-0.5">
          Organization preferences, workflow configurations, and developer access
        </p>
      </div>

      {/* Tabs */}
      <div className="border-b border-[#c7c4d8]/30 flex items-center gap-6 text-xs font-semibold">
        <button
          onClick={() => setActiveSettingsTab('general')}
          className={`pb-3 flex items-center gap-2 border-b-2 transition-colors cursor-pointer ${
            activeSettingsTab === 'general'
              ? 'border-[#3525cd] text-[#3525cd]'
              : 'border-transparent text-[#777587] hover:text-[#0b1c30]'
          }`}
        >
          <span className="material-symbols-outlined text-[16px]">tune</span>
          <span>General &amp; Profile</span>
        </button>
        <button
          onClick={() => setActiveSettingsTab('notifications')}
          className={`pb-3 flex items-center gap-2 border-b-2 transition-colors cursor-pointer ${
            activeSettingsTab === 'notifications'
              ? 'border-[#3525cd] text-[#3525cd]'
              : 'border-transparent text-[#777587] hover:text-[#0b1c30]'
          }`}
        >
          <span className="material-symbols-outlined text-[16px]">notifications</span>
          <span>Alert Preferences</span>
        </button>
        <button
          onClick={() => setActiveSettingsTab('members')}
          className={`pb-3 flex items-center gap-2 border-b-2 transition-colors cursor-pointer ${
            activeSettingsTab === 'members'
              ? 'border-[#3525cd] text-[#3525cd]'
              : 'border-transparent text-[#777587] hover:text-[#0b1c30]'
          }`}
        >
          <span className="material-symbols-outlined text-[16px]">shield_person</span>
          <span>Security &amp; Roles</span>
        </button>
      </div>

      {/* Tab 1: General */}
      {activeSettingsTab === 'general' && (
        <form onSubmit={handleSave} className="space-y-6">
          <div className="bg-white rounded-xl border border-[#c7c4d8]/40 p-5 shadow-xs space-y-4">
            <h3 className="font-headline font-bold text-sm text-[#0b1c30]">
              Workspace Identity
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block font-semibold text-[#0b1c30] mb-1">
                  Workspace Name
                </label>
                <input
                  type="text"
                  value={workspaceName}
                  onChange={(e) => setWorkspaceName(e.target.value)}
                  className="w-full px-3 py-2 border border-[#c7c4d8]/60 rounded-lg outline-none focus:border-[#3525cd]"
                />
              </div>

              <div>
                <label className="block font-semibold text-[#0b1c30] mb-1">
                  Domain URL
                </label>
                <input
                  type="text"
                  value={workspaceDomain}
                  onChange={(e) => setWorkspaceDomain(e.target.value)}
                  className="w-full px-3 py-2 border border-[#c7c4d8]/60 rounded-lg font-mono text-xs outline-none focus:border-[#3525cd]"
                />
              </div>
            </div>

            <div>
              <label className="block font-semibold text-[#0b1c30] mb-1 text-xs">
                Organization Tagline
              </label>
              <input
                type="text"
                defaultValue="Modern SaaS product engineering & project management"
                className="w-full px-3 py-2 border border-[#c7c4d8]/60 rounded-lg text-xs outline-none focus:border-[#3525cd]"
              />
            </div>
          </div>

          <div className="bg-white rounded-xl border border-[#c7c4d8]/40 p-5 shadow-xs space-y-4">
            <h3 className="font-headline font-bold text-sm text-[#0b1c30]">
              Admin User Profile
            </h3>

            <div className="flex items-center gap-4">
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                className="w-14 h-14 rounded-full object-cover border-2 border-white shadow-xs"
              />
              <div className="text-xs">
                <span className="font-bold text-[#0b1c30] block text-sm">{currentUser.name}</span>
                <span className="text-[#777587] font-mono block">{currentUser.email}</span>
                <span className="inline-block mt-1 px-2 py-0.5 rounded bg-[#e2dfff] text-[#3525cd] font-semibold text-[10px]">
                  Role: {currentUser.role}
                </span>
              </div>
            </div>
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              className="bg-[#4f46e5] hover:bg-[#3525cd] text-white text-xs font-semibold px-5 py-2 rounded-lg shadow-xs transition-colors cursor-pointer"
            >
              Save Changes
            </button>
          </div>
        </form>
      )}

      {/* Tab 2: Notifications */}
      {activeSettingsTab === 'notifications' && (
        <form onSubmit={handleSave} className="space-y-6">
          <div className="bg-white rounded-xl border border-[#c7c4d8]/40 p-5 shadow-xs space-y-4 text-xs">
            <h3 className="font-headline font-bold text-sm text-[#0b1c30]">
              Notification Triggers
            </h3>

            <div className="space-y-3">
              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={emailDigest}
                  onChange={(e) => setEmailDigest(e.target.checked)}
                  className="w-4 h-4 rounded text-[#3525cd] focus:ring-[#3525cd] mt-0.5"
                />
                <div>
                  <span className="font-bold text-[#0b1c30] block">Daily Sprint Digest</span>
                  <span className="text-[#777587] text-[11px]">
                    Receive an aggregated morning overview of tasks due, blocked tickets, and milestone progress.
                  </span>
                </div>
              </label>

              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={desktopPush}
                  onChange={(e) => setDesktopPush(e.target.checked)}
                  className="w-4 h-4 rounded text-[#3525cd] focus:ring-[#3525cd] mt-0.5"
                />
                <div>
                  <span className="font-bold text-[#0b1c30] block">Real-time Task Mentions</span>
                  <span className="text-[#777587] text-[11px]">
                    Notify immediately when a teammate assigns a task, leaves a comment, or flags an urgent blocker.
                  </span>
                </div>
              </label>
            </div>
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              className="bg-[#4f46e5] hover:bg-[#3525cd] text-white text-xs font-semibold px-5 py-2 rounded-lg shadow-xs transition-colors cursor-pointer"
            >
              Update Preferences
            </button>
          </div>
        </form>
      )}

      {/* Tab 3: Security & Roles */}
      {activeSettingsTab === 'members' && (
        <div className="bg-white rounded-xl border border-[#c7c4d8]/40 p-5 shadow-xs space-y-4 text-xs">
          <h3 className="font-headline font-bold text-sm text-[#0b1c30]">
            Role-Based Access Control (RBAC)
          </h3>
          <p className="text-xs text-[#777587]">
            Configured permissions for engineering collaborators and observers.
          </p>

          <div className="space-y-2 pt-2">
            <div className="p-3 rounded-lg bg-[#f8f9ff] border border-[#c7c4d8]/20 flex items-center justify-between">
              <div>
                <span className="font-bold text-[#0b1c30] block">Workspace Admin</span>
                <span className="text-[11px] text-[#777587]">
                  Full access to launch projects, edit OKRs, and delete milestone deliverables.
                </span>
              </div>
              <span className="font-mono text-xs font-bold text-[#3525cd]">1 Member (Alex)</span>
            </div>

            <div className="p-3 rounded-lg bg-[#f8f9ff] border border-[#c7c4d8]/20 flex items-center justify-between">
              <div>
                <span className="font-bold text-[#0b1c30] block">Core Engineer / Contributor</span>
                <span className="text-[11px] text-[#777587]">
                  Can create tasks, advance Kanban cards, post comments, and upload sprint assets.
                </span>
              </div>
              <span className="font-mono text-xs font-bold text-[#006c49]">4 Members</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
