import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';

export const ProjectsView: React.FC = () => {
  const { projects, openProjectDetails, openCreateModal } = useApp();
  const [filter, setFilter] = useState<'all' | 'active' | 'urgent'>('all');
  const [search, setSearch] = useState('');

  const filteredProjects = projects.filter((p) => {
    const matchesFilter =
      filter === 'all'
        ? true
        : filter === 'active'
        ? p.status === 'active'
        : p.priority === 'urgent' || p.priority === 'high';
    const matchesSearch =
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.code.toLowerCase().includes(search.toLowerCase()) ||
      p.category.toLowerCase().includes(search.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-150">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-headline font-bold text-xl text-[#0b1c30]">Active Initiatives</h1>
          <p className="text-xs text-[#777587] mt-0.5">
            Cross-functional development projects mapped to company quarterly goals
          </p>
        </div>

        <button
          id="new-project-btn"
          onClick={() => openCreateModal('project')}
          className="bg-[#4f46e5] hover:bg-[#3525cd] text-white text-xs font-semibold px-4 py-2 rounded-lg flex items-center gap-1.5 transition-all shadow-xs self-start sm:self-auto cursor-pointer"
        >
          <span className="material-symbols-outlined text-[16px]">add</span>
          <span>+ Create Project</span>
        </button>
      </div>

      {/* Filter and search toolbar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-white p-3 rounded-xl border border-[#c7c4d8]/40 shadow-2xs">
        <div className="flex items-center gap-1 bg-[#f8f9ff] p-1 rounded-lg w-full sm:w-auto">
          <button
            onClick={() => setFilter('all')}
            className={`px-3 py-1 rounded-md text-xs font-semibold transition-all ${
              filter === 'all'
                ? 'bg-white text-[#3525cd] shadow-2xs'
                : 'text-[#464555] hover:text-[#0b1c30]'
            }`}
          >
            All ({projects.length})
          </button>
          <button
            onClick={() => setFilter('active')}
            className={`px-3 py-1 rounded-md text-xs font-semibold transition-all ${
              filter === 'active'
                ? 'bg-white text-[#3525cd] shadow-2xs'
                : 'text-[#464555] hover:text-[#0b1c30]'
            }`}
          >
            Active Sprints
          </button>
          <button
            onClick={() => setFilter('urgent')}
            className={`px-3 py-1 rounded-md text-xs font-semibold transition-all ${
              filter === 'urgent'
                ? 'bg-white text-[#3525cd] shadow-2xs'
                : 'text-[#464555] hover:text-[#0b1c30]'
            }`}
          >
            High Priority
          </button>
        </div>

        <div className="relative w-full sm:w-64">
          <span className="material-symbols-outlined absolute left-2.5 top-2 text-[#777587] text-[16px]">
            search
          </span>
          <input
            type="text"
            placeholder="Filter projects..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-8 pr-3 py-1.5 bg-[#f8f9ff] border border-[#c7c4d8]/50 rounded-lg text-xs text-[#0b1c30] outline-none focus:border-[#3525cd]"
          />
        </div>
      </div>

      {/* Projects Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredProjects.map((proj) => (
          <div
            key={proj.id}
            onClick={() => openProjectDetails(proj.id)}
            className="bg-white rounded-xl border border-[#c7c4d8]/40 p-5 shadow-xs hover:shadow-md hover:border-[#3525cd]/50 transition-all cursor-pointer flex flex-col justify-between group"
          >
            <div>
              <div className="flex items-start justify-between gap-3 mb-2">
                <span className="font-mono text-xs font-bold text-[#3525cd] bg-[#e2dfff] px-2 py-0.5 rounded">
                  {proj.code}
                </span>
                <span
                  className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full ${
                    proj.priority === 'urgent'
                      ? 'bg-[#ffdad6] text-[#ba1a1a]'
                      : proj.priority === 'high'
                      ? 'bg-[#ffddb8] text-[#684000]'
                      : 'bg-[#e5eeff] text-[#464555]'
                  }`}
                >
                  ● {proj.priority}
                </span>
              </div>

              <h3 className="font-headline font-bold text-base text-[#0b1c30] group-hover:text-[#3525cd] transition-colors mb-1">
                {proj.name}
              </h3>
              <span className="text-[11px] font-medium text-[#777587] block mb-2">
                {proj.category}
              </span>

              <p className="text-xs text-[#464555] line-clamp-3 leading-relaxed mb-4">
                {proj.description}
              </p>
            </div>

            <div className="pt-4 border-t border-[#c7c4d8]/20 space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="text-[#777587]">
                  Tasks: <strong className="text-[#0b1c30]">{proj.completedTasks}/{proj.totalTasks}</strong>
                </span>
                <span className="font-mono font-bold text-[#006c49]">
                  {proj.progressPercentage}%
                </span>
              </div>

              <div className="w-full bg-[#e5eeff] rounded-full h-1.5 overflow-hidden">
                <div
                  className="bg-[#3525cd] h-1.5 rounded-full transition-all duration-300"
                  style={{ width: `${proj.progressPercentage}%` }}
                />
              </div>

              <div className="flex items-center justify-between pt-1">
                <div className="flex items-center gap-1.5 text-xs text-[#777587]">
                  <span className="material-symbols-outlined text-[14px]">event</span>
                  <span>{proj.deadlineLabel || proj.deadline}</span>
                </div>

                <div className="flex -space-x-1.5">
                  {proj.assigneeIds.map((id, idx) => (
                    <div
                      key={idx}
                      className="w-6 h-6 rounded-full border-2 border-white bg-[#e2dfff] text-[#3525cd] text-[10px] font-bold flex items-center justify-center font-mono"
                      title={id}
                    >
                      {id.slice(-2).toUpperCase()}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
