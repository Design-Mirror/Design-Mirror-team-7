import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';

export const MessagesView: React.FC = () => {
  const { messages, sendMessage } = useApp();
  const [activeChannel, setActiveChannel] = useState('college-event-app');
  const [inputMessage, setInputMessage] = useState('');

  const channels = [
    {
      id: 'college-event-app',
      name: 'college-event-app',
      topic: 'Q3 Campus release sync, API testing & mobile UI',
      members: 5,
    },
    {
      id: 'e-commerce-platform',
      name: 'e-commerce-platform',
      topic: 'Cart checkout performance & payment webhooks',
      members: 4,
    },
    {
      id: 'general-engineering',
      name: 'general-engineering',
      topic: 'Architecture RFCs, tech stack discussions, DevOps',
      members: 5,
    },
    {
      id: 'announcements',
      name: 'announcements',
      topic: 'Sprint milestones & release schedules',
      members: 5,
    },
  ];

  const currentChannelObj = channels.find((c) => c.id === activeChannel) || channels[0];
  const channelMessages = messages.filter((m) => m.channelId === activeChannel);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim()) return;
    sendMessage(activeChannel, inputMessage.trim());
    setInputMessage('');
  };

  return (
    <div className="h-[calc(100vh-140px)] flex flex-col md:flex-row bg-white rounded-xl border border-[#c7c4d8]/40 overflow-hidden shadow-xs animate-in fade-in duration-150">
      {/* Channels Sidebar */}
      <div className="w-full md:w-64 border-r border-[#c7c4d8]/30 flex flex-col shrink-0 bg-[#f8f9ff]">
        <div className="p-3.5 border-b border-[#c7c4d8]/20 flex items-center justify-between">
          <span className="font-headline font-bold text-xs text-[#0b1c30] uppercase tracking-wider">
            Channels
          </span>
          <span className="material-symbols-outlined text-[18px] text-[#777587]">tag</span>
        </div>

        <div className="p-2 space-y-1 overflow-y-auto custom-scrollbar flex-1">
          {channels.map((ch) => {
            const isActive = ch.id === activeChannel;
            return (
              <button
                key={ch.id}
                onClick={() => setActiveChannel(ch.id)}
                className={`w-full text-left px-3 py-2 rounded-lg text-xs font-semibold flex items-center justify-between transition-colors cursor-pointer ${
                  isActive
                    ? 'bg-white text-[#3525cd] shadow-2xs'
                    : 'text-[#464555] hover:bg-white/60 hover:text-[#0b1c30]'
                }`}
              >
                <div className="flex items-center gap-2 truncate">
                  <span className="font-mono text-[#777587]">#</span>
                  <span className="truncate">{ch.name}</span>
                </div>
                <span className="text-[10px] text-[#777587] font-mono">{ch.members}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Chat Conversation Area */}
      <div className="flex-1 flex flex-col min-w-0 bg-white">
        {/* Chat Header */}
        <div className="p-3.5 border-b border-[#c7c4d8]/25 flex items-center justify-between bg-[#f8f9ff]">
          <div>
            <div className="flex items-center gap-2">
              <span className="font-mono font-bold text-sm text-[#0b1c30]">
                #{currentChannelObj.name}
              </span>
              <span className="text-[10px] font-semibold bg-[#e2dfff] text-[#3525cd] px-1.5 py-0.2 rounded">
                Active Sprint Channel
              </span>
            </div>
            <p className="text-[11px] text-[#777587] mt-0.5">{currentChannelObj.topic}</p>
          </div>

          <div className="flex items-center gap-2 text-xs text-[#777587]">
            <span className="material-symbols-outlined text-[18px]">group</span>
            <span>{currentChannelObj.members} members</span>
          </div>
        </div>

        {/* Messages Stream */}
        <div className="flex-1 p-4 overflow-y-auto custom-scrollbar space-y-4">
          {channelMessages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-[#777587] text-xs">
              <span className="material-symbols-outlined text-3xl mb-1 text-[#c7c4d8]">forum</span>
              <span>No messages in this channel yet. Start the conversation!</span>
            </div>
          ) : (
            channelMessages.map((msg) => (
              <div key={msg.id} className="flex items-start gap-3 group">
                <img
                  src={msg.senderAvatar}
                  alt={msg.senderName}
                  className="w-8 h-8 rounded-full object-cover shrink-0 mt-0.5 border border-[#c7c4d8]/30"
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-baseline gap-2 mb-1">
                    <span className="font-bold text-xs text-[#0b1c30]">{msg.senderName}</span>
                    <span className="text-[10px] text-[#777587] font-medium">({msg.senderRole})</span>
                    <span className="text-[10px] text-[#777587] font-mono">{msg.timestamp}</span>
                  </div>
                  <div className="bg-[#f8f9ff] group-hover:bg-[#eff4ff]/50 transition-colors p-3 rounded-xl rounded-tl-none border border-[#c7c4d8]/20 text-xs text-[#0b1c30] leading-relaxed max-w-2xl">
                    {msg.content}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Message Input Box */}
        <div className="p-3 border-t border-[#c7c4d8]/25 bg-[#f8f9ff]">
          <form onSubmit={handleSend} className="flex items-center gap-2">
            <input
              type="text"
              placeholder={`Message #${currentChannelObj.name}...`}
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              className="flex-1 bg-white border border-[#c7c4d8]/60 rounded-xl px-4 py-2 text-xs text-[#0b1c30] outline-none focus:border-[#3525cd]"
            />
            <button
              type="submit"
              disabled={!inputMessage.trim()}
              className="bg-[#4f46e5] hover:bg-[#3525cd] disabled:opacity-40 text-white text-xs font-semibold px-4 py-2 rounded-xl flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
            >
              <span>Send</span>
              <span className="material-symbols-outlined text-[15px]">send</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
