import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';

export const GoalsMilestonesView: React.FC = () => {
  const {
    goals,
    milestones,
    projects,
    openCreateModal,
    openProjectDetails,
  } = useApp();

  const [selectedGoalId, setSelectedGoalId] = useState<string>(goals[0]?.id || 'goal-1');

  const currentGoal = goals.find((g) => g.id === selectedGoalId) || goals[0];
  const goalProjects = projects.filter((p) => currentGoal?.projectIds.includes(p.id));
  const activeMilestones = milestones.filter((m) =>
    goalProjects.some((p) => p.id === m.projectId)
  );

  return (
    <div className="space-y-6 animate-in fade-in duration-150">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-headline font-bold text-xl text-[#0b1c30]">
            Goals &amp; Strategic Milestones
          </h1>
          <p className="text-xs text-[#777587] mt-0.5">
            Executive OKRs, delivery timeline, and high-level milestones
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => openCreateModal('milestone')}
            className="px-3 py-1.5 bg-[#eff4ff] hover:bg-[#dce9ff] text-[#3525cd] text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <span className="material-symbols-outlined text-[16px]">flag</span>
            <span>+ Add Milestone</span>
          </button>
          <button
            onClick={() => openCreateModal('goal')}
            className="px-3 py-1.5 bg-[#4f46e5] hover:bg-[#3525cd] text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
          >
            <span className="material-symbols-outlined text-[16px]">add</span>
            <span>+ Establish Goal</span>
          </button>
        </div>
      </div>

      {/* OKR / Goal Selector Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {goals.map((g) => {
          const isSelected = g.id === currentGoal?.id;

          return (
            <div
              key={g.id}
              onClick={() => setSelectedGoalId(g.id)}
              className={`p-4 rounded-xl border transition-all cursor-pointer ${
                isSelected
                  ? 'bg-white border-[#3525cd] shadow-md ring-1 ring-[#3525cd]/30'
                  : 'bg-white border-[#c7c4d8]/40 hover:border-[#3525cd]/40'
              }`}
            >
              <div className="flex items-start justify-between gap-2 mb-2">
                <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-[#3525cd] bg-[#e2dfff] px-2 py-0.5 rounded">
                  Goal #{g.goalNumber} • {g.quarter}
                </span>
                <span
                  className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full ${
                    g.status === 'On Track'
                      ? 'bg-[#6cf8bb]/30 text-[#00714d]'
                      : 'bg-[#ffdad6] text-[#ba1a1a]'
                  }`}
                >
                  ● {g.status}
                </span>
              </div>

              <h3 className="font-headline font-bold text-sm text-[#0b1c30] mb-1 leading-snug">
                {g.title}
              </h3>
              <p className="text-xs text-[#464555] line-clamp-2 mb-3">
                <strong className="text-[#0b1c30]">Key Result:</strong> {g.keyResult}
              </p>

              <div className="pt-2 border-t border-[#c7c4d8]/20 space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-[#777587]">
                    Milestones: <strong>{g.milestonesScoped}/{g.totalMilestones}</strong>
                  </span>
                  <span className="font-mono font-bold text-[#006c49]">
                    {g.velocityPercentage}%
                  </span>
                </div>

                <div className="w-full bg-[#e5eeff] rounded-full h-1.5 overflow-hidden">
                  <div
                    className="bg-[#3525cd] h-1.5 rounded-full transition-all duration-300"
                    style={{ width: `${g.velocityPercentage}%` }}
                  />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Detailed Milestone Roadmap Section */}
      <div className="bg-white rounded-xl border border-[#c7c4d8]/40 p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#c7c4d8]/25 mb-6">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="font-mono text-xs font-bold text-[#3525cd] bg-[#e2dfff] px-2 py-0.5 rounded">
                Active Roadmap
              </span>
              <h2 className="font-headline font-bold text-base text-[#0b1c30]">
                {currentGoal?.title}
              </h2>
            </div>
            <p className="text-xs text-[#777587]">
              Key Result: {currentGoal?.keyResult}
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs">
            <span className="text-[#777587]">Mapped to:</span>
            {goalProjects.map((p) => (
              <button
                key={p.id}
                onClick={() => openProjectDetails(p.id)}
                className="font-bold text-[#3525cd] hover:underline bg-[#eff4ff] px-2 py-1 rounded"
              >
                {p.name} ({p.code}) →
              </button>
            ))}
          </div>
        </div>

        {/* Milestone Timeline Sequence */}
        <div className="space-y-6 relative before:absolute before:left-4 before:top-2 before:bottom-2 before:w-0.5 before:bg-[#e5eeff]">
          {activeMilestones.map((ms) => (
            <div key={ms.id} className="relative pl-11 group">
              {/* Timeline marker icon */}
              <div
                className={`absolute left-1.5 top-1 w-6 h-6 rounded-full flex items-center justify-center font-bold text-xs shadow-xs ring-4 ring-white ${
                  ms.status === 'completed'
                    ? 'bg-[#006c49] text-white'
                    : ms.status === 'in_progress'
                    ? 'bg-[#3525cd] text-white'
                    : 'bg-[#c7c4d8] text-white'
                }`}
              >
                {ms.status === 'completed' ? (
                  <span className="material-symbols-outlined text-[14px]">check</span>
                ) : (
                  ms.number
                )}
              </div>

              {/* Milestone Details Card */}
              <div
                className={`p-4 rounded-xl border transition-all ${
                  ms.isAtRisk
                    ? 'border-[#ba1a1a]/40 bg-[#fff8f7]'
                    : 'border-[#c7c4d8]/30 bg-[#f8f9ff] hover:bg-white'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-2">
                  <div className="flex items-center gap-2.5">
                    <h4 className="font-headline font-bold text-sm text-[#0b1c30]">
                      Milestone {ms.number}: {ms.title}
                    </h4>
                    {ms.isAtRisk && (
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#ffdad6] text-[#ba1a1a] flex items-center gap-1">
                        <span className="material-symbols-outlined text-[12px]">warning</span>
                        Risk Detected
                      </span>
                    )}
                  </div>

                  <span
                    className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full self-start sm:self-auto ${
                      ms.status === 'completed'
                        ? 'bg-[#6cf8bb]/30 text-[#00714d]'
                        : ms.status === 'in_progress'
                        ? 'bg-[#e2dfff] text-[#3525cd]'
                        : 'bg-[#e5eeff] text-[#464555]'
                    }`}
                  >
                    ● {ms.status.replace('_', ' ')}
                  </span>
                </div>

                <p className="text-xs text-[#464555] mb-2 leading-relaxed">{ms.description}</p>

                {ms.riskDescription && (
                  <div className="p-2 rounded bg-[#ffdad6]/40 border border-[#ba1a1a]/20 text-xs text-[#ba1a1a] font-medium mb-3 flex items-center gap-2">
                    <span className="material-symbols-outlined text-[16px]">error</span>
                    <span>{ms.riskDescription}</span>
                  </div>
                )}

                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs pt-2 border-t border-[#c7c4d8]/20">
                  <div className="flex items-center gap-3 text-[#777587]">
                    <span>
                      Owner: <strong>{ms.ownerName}</strong> ({ms.ownerRole})
                    </span>
                    <span>•</span>
                    <span className="text-[#ba1a1a] font-semibold">
                      Target: {ms.deadline}
                    </span>
                    {ms.completedDate && (
                      <span className="text-[#006c49]">
                        (Done {ms.completedDate})
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="w-28 bg-[#e5eeff] rounded-full h-1.5 overflow-hidden">
                      <div
                        className="bg-[#3525cd] h-1.5 rounded-full"
                        style={{ width: `${ms.progressPercentage}%` }}
                      />
                    </div>
                    <span className="font-mono font-bold text-xs text-[#006c49]">
                      {ms.progressPercentage}%
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
