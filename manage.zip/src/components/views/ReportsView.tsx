import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';

export const ReportsView: React.FC = () => {
  const { projects, tasks, teamMembers, addToast } = useApp();
  const [dateRange, setDateRange] = useState('Sprint 3 (Sept 1 - Sept 20)');

  const handleExport = (format: string) => {
    addToast({
      type: 'success',
      title: 'Report Generated',
      message: `Exported sprint analytics report as ${format.toUpperCase()}. File ready for download.`,
    });
  };

  const totalTasks = tasks.length;
  const doneTasks = tasks.filter((t) => t.status === 'done').length;
  const inProgressTasks = tasks.filter((t) => t.status === 'in_progress').length;
  const reviewTasks = tasks.filter((t) => t.status === 'review').length;
  const todoTasks = tasks.filter((t) => t.status === 'todo' || t.status === 'backlog').length;

  const donePercent = Math.round((doneTasks / totalTasks) * 100) || 0;
  const inProgressPercent = Math.round((inProgressTasks / totalTasks) * 100) || 0;
  const reviewPercent = Math.round((reviewTasks / totalTasks) * 100) || 0;
  const todoPercent = Math.round((todoTasks / totalTasks) * 100) || 0;

  return (
    <div className="space-y-6 animate-in fade-in duration-150">
      {/* Header & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-headline font-bold text-xl text-[#0b1c30]">
            Performance &amp; Velocity Reports
          </h1>
          <p className="text-xs text-[#777587] mt-0.5">
            Engineering throughput, burn-down metrics, and resource allocation
          </p>
        </div>

        <div className="flex items-center gap-2">
          <select
            value={dateRange}
            onChange={(e) => setDateRange(e.target.value)}
            className="bg-white border border-[#c7c4d8]/50 rounded-lg px-3 py-1.5 text-xs text-[#0b1c30] font-semibold outline-none shadow-2xs"
          >
            <option value="Sprint 3 (Sept 1 - Sept 20)">Sprint 3 (Sept 1 - Sept 20)</option>
            <option value="Sprint 2 (Aug 15 - Aug 31)">Sprint 2 (Aug 15 - Aug 31)</option>
            <option value="Q3 2024 (Full Quarter)">Q3 2024 (Full Quarter)</option>
          </select>

          <button
            onClick={() => handleExport('csv')}
            className="px-3 py-1.5 bg-white border border-[#c7c4d8]/40 hover:bg-[#eff4ff] text-[#0b1c30] text-xs font-semibold rounded-lg flex items-center gap-1.5 shadow-2xs transition-colors cursor-pointer"
          >
            <span className="material-symbols-outlined text-[16px] text-[#006c49]">download</span>
            <span>Export CSV</span>
          </button>

          <button
            onClick={() => handleExport('pdf')}
            className="px-3 py-1.5 bg-[#4f46e5] hover:bg-[#3525cd] text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
          >
            <span className="material-symbols-outlined text-[16px]">picture_as_pdf</span>
            <span>Export PDF</span>
          </button>
        </div>
      </div>

      {/* KPI Overview Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-[#c7c4d8]/40 shadow-xs">
          <span className="text-xs font-semibold text-[#777587] block mb-1">Sprint Completion</span>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-headline text-[#006c49]">{donePercent}%</span>
            <span className="text-xs text-[#777587]">of scoped tasks</span>
          </div>
          <span className="text-[11px] text-[#777587] block mt-2">
            {doneTasks} delivered out of {totalTasks}
          </span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-[#c7c4d8]/40 shadow-xs">
          <span className="text-xs font-semibold text-[#777587] block mb-1">Active Cycle Time</span>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-headline text-[#0b1c30]">2.8 Days</span>
            <span className="text-xs font-semibold text-[#006c49]">-0.4d faster</span>
          </div>
          <span className="text-[11px] text-[#777587] block mt-2">
            Average time from In Progress to Review
          </span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-[#c7c4d8]/40 shadow-xs">
          <span className="text-xs font-semibold text-[#777587] block mb-1">PR Merge Rate</span>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-headline text-[#3525cd]">94.2%</span>
            <span className="text-xs text-[#777587]">first pass</span>
          </div>
          <span className="text-[11px] text-[#777587] block mt-2">
            28 pull requests merged this sprint
          </span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-[#c7c4d8]/40 shadow-xs">
          <span className="text-xs font-semibold text-[#777587] block mb-1">Milestones Scoped</span>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-headline text-[#0b1c30]">5 of 6</span>
            <span className="text-xs font-semibold text-[#ba1a1a]">1 at risk</span>
          </div>
          <span className="text-[11px] text-[#777587] block mt-2">
            Target launch date: Oct 1, 2024
          </span>
        </div>
      </div>

      {/* Task Distribution & Status Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Status Distribution Progress */}
        <div className="bg-white p-5 rounded-xl border border-[#c7c4d8]/40 shadow-xs">
          <h3 className="font-headline font-bold text-sm text-[#0b1c30] mb-1">
            Task Status Distribution
          </h3>
          <p className="text-xs text-[#777587] mb-4">Breakdown across all active engineering tasks</p>

          {/* Segmented Bar */}
          <div className="w-full h-4 rounded-full flex overflow-hidden mb-5 bg-[#e5eeff]">
            <div
              className="bg-[#006c49] h-full"
              style={{ width: `${donePercent}%` }}
              title={`Done: ${donePercent}%`}
            />
            <div
              className="bg-[#3525cd] h-full"
              style={{ width: `${inProgressPercent}%` }}
              title={`In Progress: ${inProgressPercent}%`}
            />
            <div
              className="bg-[#684000] h-full"
              style={{ width: `${reviewPercent}%` }}
              title={`Review: ${reviewPercent}%`}
            />
            <div
              className="bg-[#777587] h-full"
              style={{ width: `${todoPercent}%` }}
              title={`To Do & Backlog: ${todoPercent}%`}
            />
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="p-2.5 rounded-lg bg-[#f8f9ff] border border-[#c7c4d8]/20 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#006c49]" />
                <span className="font-medium text-[#0b1c30]">Done</span>
              </div>
              <span className="font-mono font-bold text-[#006c49]">{doneTasks} ({donePercent}%)</span>
            </div>

            <div className="p-2.5 rounded-lg bg-[#f8f9ff] border border-[#c7c4d8]/20 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#3525cd]" />
                <span className="font-medium text-[#0b1c30]">In Progress</span>
              </div>
              <span className="font-mono font-bold text-[#3525cd]">{inProgressTasks} ({inProgressPercent}%)</span>
            </div>

            <div className="p-2.5 rounded-lg bg-[#f8f9ff] border border-[#c7c4d8]/20 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#684000]" />
                <span className="font-medium text-[#0b1c30]">Review</span>
              </div>
              <span className="font-mono font-bold text-[#684000]">{reviewTasks} ({reviewPercent}%)</span>
            </div>

            <div className="p-2.5 rounded-lg bg-[#f8f9ff] border border-[#c7c4d8]/20 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#777587]" />
                <span className="font-medium text-[#0b1c30]">Backlog &amp; To Do</span>
              </div>
              <span className="font-mono font-bold text-[#777587]">{todoTasks} ({todoPercent}%)</span>
            </div>
          </div>
        </div>

        {/* Project Health & Delivery Velocity */}
        <div className="bg-white p-5 rounded-xl border border-[#c7c4d8]/40 shadow-xs">
          <h3 className="font-headline font-bold text-sm text-[#0b1c30] mb-1">
            Initiative Velocity
          </h3>
          <p className="text-xs text-[#777587] mb-4">Progress comparison against target milestone dates</p>

          <div className="space-y-4">
            {projects.map((proj) => (
              <div key={proj.id} className="space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-[10px] text-[#3525cd] bg-[#e2dfff] px-1.5 py-0.2 rounded">
                      {proj.code}
                    </span>
                    <span className="font-semibold text-[#0b1c30]">{proj.name}</span>
                  </div>
                  <span className="font-mono font-bold text-[#006c49]">
                    {proj.progressPercentage}%
                  </span>
                </div>

                <div className="w-full bg-[#e5eeff] rounded-full h-2 overflow-hidden">
                  <div
                    className="bg-[#3525cd] h-2 rounded-full"
                    style={{ width: `${proj.progressPercentage}%` }}
                  />
                </div>

                <div className="flex items-center justify-between text-[11px] text-[#777587]">
                  <span>{proj.completedTasks} of {proj.totalTasks} completed</span>
                  <span>Target: {proj.deadlineLabel}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Team Member Contribution Breakdown */}
      <div className="bg-white rounded-xl border border-[#c7c4d8]/40 p-5 shadow-xs">
        <h3 className="font-headline font-bold text-sm text-[#0b1c30] mb-1">
          Individual Throughput &amp; Load
        </h3>
        <p className="text-xs text-[#777587] mb-4">Sprint velocity per core engineer</p>

        <div className="space-y-3">
          {teamMembers.map((member) => (
            <div
              key={member.id}
              className="p-3 rounded-lg bg-[#f8f9ff] border border-[#c7c4d8]/20 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
            >
              <div className="flex items-center gap-3">
                <img
                  src={member.avatar}
                  alt={member.name}
                  className="w-8 h-8 rounded-full object-cover border border-white"
                />
                <div>
                  <h4 className="font-bold text-[#0b1c30]">{member.name}</h4>
                  <span className="text-[11px] text-[#777587]">{member.role}</span>
                </div>
              </div>

              <div className="flex items-center gap-6">
                <div>
                  <span className="text-[10px] text-[#777587] block">Assigned Tasks</span>
                  <span className="font-semibold text-[#0b1c30]">{member.assignedTasksCount} tasks</span>
                </div>

                <div className="w-36">
                  <div className="flex justify-between text-[10px] mb-1">
                    <span className="text-[#777587]">Load</span>
                    <span className="font-bold text-[#3525cd]">{member.capacityPercentage}%</span>
                  </div>
                  <div className="w-full bg-[#e5eeff] rounded-full h-1.5 overflow-hidden">
                    <div
                      className={`h-1.5 rounded-full ${
                        member.capacityPercentage > 90 ? 'bg-[#ba1a1a]' : 'bg-[#3525cd]'
                      }`}
                      style={{ width: `${member.capacityPercentage}%` }}
                    />
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
