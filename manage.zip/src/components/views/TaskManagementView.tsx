import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TaskStatus, TaskPriority } from '../../types';

export const TaskManagementView: React.FC = () => {
  const {
    tasks,
    projects,
    teamMembers,
    openTaskDetails,
    openCreateModal,
    updateTaskStatus,
  } = useApp();

  const [viewMode, setViewMode] = useState<'board' | 'list'>('board');
  const [selectedProjectFilter, setSelectedProjectFilter] = useState<string>('all');
  const [selectedPriorityFilter, setSelectedPriorityFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const columns: { id: TaskStatus; title: string; color: string }[] = [
    { id: 'backlog', title: 'Backlog', color: 'border-t-slate-400' },
    { id: 'todo', title: 'To Do', color: 'border-t-indigo-500' },
    { id: 'in_progress', title: 'In Progress', color: 'border-t-blue-600' },
    { id: 'review', title: 'Review', color: 'border-t-amber-500' },
    { id: 'done', title: 'Done', color: 'border-t-emerald-500' },
  ];

  const filteredTasks = tasks.filter((t) => {
    const matchesProject =
      selectedProjectFilter === 'all' || t.projectId === selectedProjectFilter;
    const matchesPriority =
      selectedPriorityFilter === 'all' || t.priority === selectedPriorityFilter;
    const matchesSearch =
      t.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.code.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesProject && matchesPriority && matchesSearch;
  });

  return (
    <div className="space-y-5 animate-in fade-in duration-150">
      {/* Top Header & View Toggle */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-headline font-bold text-xl text-[#0b1c30]">Task Management</h1>
          <p className="text-xs text-[#777587] mt-0.5">
            Sprint tracking, workflow stages, and task lifecycle management
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Board / List switch */}
          <div className="bg-[#f8f9ff] p-1 rounded-lg border border-[#c7c4d8]/40 flex items-center gap-1">
            <button
              onClick={() => setViewMode('board')}
              className={`px-3 py-1 rounded-md text-xs font-semibold flex items-center gap-1 transition-all ${
                viewMode === 'board'
                  ? 'bg-white text-[#3525cd] shadow-2xs'
                  : 'text-[#464555] hover:text-[#0b1c30]'
              }`}
            >
              <span className="material-symbols-outlined text-[16px]">view_kanban</span>
              <span>Board</span>
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`px-3 py-1 rounded-md text-xs font-semibold flex items-center gap-1 transition-all ${
                viewMode === 'list'
                  ? 'bg-white text-[#3525cd] shadow-2xs'
                  : 'text-[#464555] hover:text-[#0b1c30]'
              }`}
            >
              <span className="material-symbols-outlined text-[16px]">view_list</span>
              <span>List</span>
            </button>
          </div>

          <button
            onClick={() => openCreateModal('task')}
            className="bg-[#4f46e5] hover:bg-[#3525cd] text-white text-xs font-semibold px-3 py-1.5 rounded-lg flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
          >
            <span className="material-symbols-outlined text-[16px]">add</span>
            <span>+ Add Task</span>
          </button>
        </div>
      </div>

      {/* Filter toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-3 rounded-xl border border-[#c7c4d8]/40 shadow-2xs text-xs">
        <div className="flex flex-wrap items-center gap-2">
          {/* Project Filter */}
          <div className="flex items-center gap-1.5">
            <span className="text-[#777587] font-medium">Project:</span>
            <select
              value={selectedProjectFilter}
              onChange={(e) => setSelectedProjectFilter(e.target.value)}
              className="bg-[#f8f9ff] border border-[#c7c4d8]/50 rounded-lg px-2.5 py-1 text-xs outline-none font-semibold text-[#0b1c30]"
            >
              <option value="all">All Projects ({projects.length})</option>
              {projects.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>
          </div>

          {/* Priority Filter */}
          <div className="flex items-center gap-1.5">
            <span className="text-[#777587] font-medium">Priority:</span>
            <select
              value={selectedPriorityFilter}
              onChange={(e) => setSelectedPriorityFilter(e.target.value)}
              className="bg-[#f8f9ff] border border-[#c7c4d8]/50 rounded-lg px-2.5 py-1 text-xs outline-none font-semibold text-[#0b1c30]"
            >
              <option value="all">All Priorities</option>
              <option value="urgent">Urgent</option>
              <option value="high">High</option>
              <option value="medium">Medium</option>
              <option value="low">Low</option>
            </select>
          </div>
        </div>

        {/* Search */}
        <div className="relative w-full sm:w-64">
          <span className="material-symbols-outlined absolute left-2.5 top-2 text-[#777587] text-[16px]">
            search
          </span>
          <input
            type="text"
            placeholder="Search tasks or code..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-8 pr-3 py-1 bg-[#f8f9ff] border border-[#c7c4d8]/50 rounded-lg text-xs text-[#0b1c30] outline-none"
          />
        </div>
      </div>

      {/* View Mode 1: Kanban Board */}
      {viewMode === 'board' ? (
        <div className="grid grid-cols-1 md:grid-cols-3 xl:grid-cols-5 gap-4 items-start overflow-x-auto pb-4">
          {columns.map((col) => {
            const colTasks = filteredTasks.filter((t) => t.status === col.id);

            return (
              <div
                key={col.id}
                className={`bg-[#f8f9ff] rounded-xl border border-[#c7c4d8]/30 flex flex-col max-h-[calc(100vh-250px)] border-t-4 ${col.color}`}
              >
                {/* Column Header */}
                <div className="p-3 border-b border-[#c7c4d8]/20 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-xs text-[#0b1c30] uppercase tracking-wider">
                      {col.title}
                    </span>
                    <span className="w-5 h-5 rounded-full bg-white border border-[#c7c4d8]/40 text-[10px] font-bold flex items-center justify-center text-[#464555]">
                      {colTasks.length}
                    </span>
                  </div>

                  <button
                    onClick={() => openCreateModal('task')}
                    className="text-[#777587] hover:text-[#0b1c30] p-1 rounded hover:bg-white cursor-pointer"
                    title={`Add task to ${col.title}`}
                  >
                    <span className="material-symbols-outlined text-[16px]">add</span>
                  </button>
                </div>

                {/* Task Cards Container */}
                <div className="p-2 space-y-2.5 overflow-y-auto custom-scrollbar flex-1">
                  {colTasks.map((t) => {
                    const completedChecklist = t.checklist.filter((c) => c.completed).length;

                    return (
                      <div
                        key={t.id}
                        onClick={() => openTaskDetails(t.id)}
                        className="bg-white rounded-lg border border-[#c7c4d8]/40 p-3 shadow-2xs hover:shadow-md hover:border-[#3525cd]/60 transition-all cursor-pointer group"
                      >
                        {/* Top: Code & Priority */}
                        <div className="flex items-center justify-between gap-1 mb-1.5">
                          <span className="font-mono text-[10px] font-bold text-[#3525cd] bg-[#e2dfff] px-1.5 py-0.2 rounded">
                            {t.code}
                          </span>
                          <span
                            className={`text-[9px] font-bold uppercase px-1.5 py-0.2 rounded ${
                              t.priority === 'urgent'
                                ? 'bg-[#ffdad6] text-[#ba1a1a]'
                                : t.priority === 'high'
                                ? 'bg-[#ffddb8] text-[#684000]'
                                : 'bg-[#e5eeff] text-[#464555]'
                            }`}
                          >
                            {t.priority}
                          </span>
                        </div>

                        {/* Title */}
                        <h4 className="font-semibold text-xs text-[#0b1c30] leading-snug group-hover:text-[#3525cd] transition-colors mb-1.5 line-clamp-2">
                          {t.title}
                        </h4>

                        {/* Milestone Tag if present */}
                        {t.milestoneName && (
                          <div className="text-[10px] text-[#777587] flex items-center gap-1 mb-2 font-medium">
                            <span className="material-symbols-outlined text-[12px] text-[#3525cd]">flag</span>
                            <span className="truncate">{t.milestoneName}</span>
                          </div>
                        )}

                        {/* Checklist indicator if items exist */}
                        {t.checklist.length > 0 && (
                          <div className="mb-2">
                            <div className="flex items-center justify-between text-[10px] text-[#777587] mb-1">
                              <span className="flex items-center gap-1">
                                <span className="material-symbols-outlined text-[12px]">check_box</span>
                                Subtasks
                              </span>
                              <span className="font-mono font-semibold">
                                {completedChecklist}/{t.checklist.length}
                              </span>
                            </div>
                            <div className="w-full bg-[#e5eeff] rounded-full h-1 overflow-hidden">
                              <div
                                className="bg-[#3525cd] h-1 rounded-full"
                                style={{
                                  width: `${Math.round(
                                    (completedChecklist / t.checklist.length) * 100
                                  )}%`,
                                }}
                              />
                            </div>
                          </div>
                        )}

                        {/* Footer: Due date + Assignee + Quick move */}
                        <div className="pt-2 border-t border-[#c7c4d8]/20 flex items-center justify-between text-[11px]">
                          <span className="text-[#ba1a1a] font-medium flex items-center gap-1 text-[10px]">
                            <span className="material-symbols-outlined text-[12px]">schedule</span>
                            {t.dueLabel || t.dueDate}
                          </span>

                          <div className="flex items-center gap-1.5">
                            {/* Quick status cycle button */}
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                const statusOrder: TaskStatus[] = ['backlog', 'todo', 'in_progress', 'review', 'done'];
                                const currentIndex = statusOrder.indexOf(t.status);
                                const nextIndex = (currentIndex + 1) % statusOrder.length;
                                updateTaskStatus(t.id, statusOrder[nextIndex]);
                              }}
                              className="text-[#777587] hover:text-[#3525cd] p-0.5 rounded hover:bg-[#eff4ff]"
                              title="Advance task to next column"
                            >
                              <span className="material-symbols-outlined text-[14px]">arrow_forward</span>
                            </button>

                            <img
                              src={t.assigneeAvatar}
                              alt={t.assigneeName}
                              className="w-5 h-5 rounded-full object-cover border border-white shadow-2xs"
                              title={t.assigneeName}
                            />
                          </div>
                        </div>
                      </div>
                    );
                  })}

                  {colTasks.length === 0 && (
                    <div className="py-8 text-center text-[11px] text-[#777587] border border-dashed border-[#c7c4d8]/40 rounded-lg">
                      No tasks in {col.title}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* View Mode 2: List View */
        <div className="bg-white rounded-xl border border-[#c7c4d8]/40 overflow-hidden shadow-xs">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#eff4ff]/60 border-b border-[#c7c4d8]/20 text-[#777587] uppercase font-semibold">
                <tr>
                  <th className="py-2.5 px-4">Task Name</th>
                  <th className="py-2.5 px-3">Project</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3">Priority</th>
                  <th className="py-2.5 px-3">Assignee</th>
                  <th className="py-2.5 px-3">Due Date</th>
                  <th className="py-2.5 px-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#c7c4d8]/15">
                {filteredTasks.map((t) => (
                  <tr
                    key={t.id}
                    onClick={() => openTaskDetails(t.id)}
                    className="hover:bg-[#f8f9ff] cursor-pointer transition-colors"
                  >
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-[11px] font-bold text-[#3525cd] bg-[#e2dfff] px-1.5 py-0.5 rounded">
                          {t.code}
                        </span>
                        <span className="font-semibold text-[#0b1c30]">{t.title}</span>
                      </div>
                    </td>
                    <td className="py-3 px-3 text-[#777587]">{t.projectName}</td>
                    <td className="py-3 px-3">
                      <span className="capitalize font-medium text-[#464555] px-2 py-0.5 rounded bg-[#eff4ff]">
                        {t.status.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="py-3 px-3">
                      <span
                        className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full ${
                          t.priority === 'urgent'
                            ? 'bg-[#ffdad6] text-[#ba1a1a]'
                            : t.priority === 'high'
                            ? 'bg-[#ffddb8] text-[#684000]'
                            : 'bg-[#e5eeff] text-[#464555]'
                        }`}
                      >
                        {t.priority}
                      </span>
                    </td>
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-1.5">
                        <img
                          src={t.assigneeAvatar}
                          alt={t.assigneeName}
                          className="w-5 h-5 rounded-full object-cover"
                        />
                        <span className="text-[#0b1c30]">{t.assigneeName}</span>
                      </div>
                    </td>
                    <td className="py-3 px-3 text-[#ba1a1a] font-medium">
                      {t.dueLabel || t.dueDate}
                    </td>
                    <td className="py-3 px-3 text-right">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          openTaskDetails(t.id);
                        }}
                        className="text-[#3525cd] hover:underline font-semibold"
                      >
                        Details →
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
