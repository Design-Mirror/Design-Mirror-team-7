import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';

export const TeamView: React.FC = () => {
  const { teamMembers, projects, setCurrentView } = useApp();
  const [selectedDept, setSelectedDept] = useState<string>('all');
  const [search, setSearch] = useState('');

  const departments = Array.from(new Set(teamMembers.map((m) => m.department)));

  const filteredMembers = teamMembers.filter((m) => {
    const matchesDept = selectedDept === 'all' || m.department === selectedDept;
    const matchesSearch =
      m.name.toLowerCase().includes(search.toLowerCase()) ||
      m.role.toLowerCase().includes(search.toLowerCase()) ||
      m.department.toLowerCase().includes(search.toLowerCase());
    return matchesDept && matchesSearch;
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-150">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-headline font-bold text-xl text-[#0b1c30]">
            Team Directory &amp; Capacity
          </h1>
          <p className="text-xs text-[#777587] mt-0.5">
            Engineering leads, individual workload velocity, and sprint allocation
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-lg border border-[#c7c4d8]/40 text-xs shadow-2xs">
            <span className="w-2 h-2 rounded-full bg-[#006c49]"></span>
            <span className="text-[#464555]">
              Active Engineers: <strong className="text-[#0b1c30]">{teamMembers.length}</strong>
            </span>
          </div>
        </div>
      </div>

      {/* Toolbar & Filters */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-white p-3 rounded-xl border border-[#c7c4d8]/40 shadow-2xs text-xs">
        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto">
          <button
            onClick={() => setSelectedDept('all')}
            className={`px-3 py-1 rounded-md text-xs font-semibold whitespace-nowrap transition-all ${
              selectedDept === 'all'
                ? 'bg-[#3525cd] text-white shadow-2xs'
                : 'bg-[#f8f9ff] text-[#464555] hover:text-[#0b1c30]'
            }`}
          >
            All Departments ({teamMembers.length})
          </button>
          {departments.map((dept) => (
            <button
              key={dept}
              onClick={() => setSelectedDept(dept)}
              className={`px-3 py-1 rounded-md text-xs font-semibold whitespace-nowrap transition-all ${
                selectedDept === dept
                  ? 'bg-[#3525cd] text-white shadow-2xs'
                  : 'bg-[#f8f9ff] text-[#464555] hover:text-[#0b1c30]'
              }`}
            >
              {dept}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-64">
          <span className="material-symbols-outlined absolute left-2.5 top-2 text-[#777587] text-[16px]">
            search
          </span>
          <input
            type="text"
            placeholder="Search member or role..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-8 pr-3 py-1 bg-[#f8f9ff] border border-[#c7c4d8]/50 rounded-lg text-xs text-[#0b1c30] outline-none"
          />
        </div>
      </div>

      {/* Team Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredMembers.map((member) => {
          const memberProjects = projects.filter((p) =>
            member.currentProjects.includes(p.id)
          );

          return (
            <div
              key={member.id}
              className="bg-white rounded-xl border border-[#c7c4d8]/40 p-5 shadow-xs hover:shadow-md transition-all flex flex-col justify-between"
            >
              <div>
                {/* Profile Header */}
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <img
                        src={member.avatar}
                        alt={member.name}
                        className="w-12 h-12 rounded-full object-cover border-2 border-white shadow-xs"
                      />
                      <span
                        className={`w-3 h-3 rounded-full absolute bottom-0 right-0 ring-2 ring-white ${
                          member.availability === 'Online'
                            ? 'bg-[#006c49]'
                            : member.availability === 'In Meeting'
                            ? 'bg-[#3525cd]'
                            : 'bg-[#ba1a1a]'
                        }`}
                        title={member.availability}
                      />
                    </div>
                    <div>
                      <h3 className="font-headline font-bold text-sm text-[#0b1c30]">
                        {member.name}
                      </h3>
                      <p className="text-xs text-[#777587]">{member.role}</p>
                      <span className="text-[10px] text-[#3525cd] font-semibold">
                        {member.department}
                      </span>
                    </div>
                  </div>

                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      member.capacityStatus === 'Optimal' || member.capacityStatus === 'Healthy'
                        ? 'bg-[#6cf8bb]/30 text-[#00714d]'
                        : 'bg-[#ffddb8] text-[#684000]'
                    }`}
                  >
                    {member.capacityStatus}
                  </span>
                </div>

                {/* Contact & Location Info */}
                <div className="space-y-1 py-2 text-[11px] text-[#464555] border-t border-[#c7c4d8]/20">
                  <div className="flex items-center gap-2">
                    <span className="material-symbols-outlined text-[14px] text-[#777587]">mail</span>
                    <span className="font-mono">{member.email}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="material-symbols-outlined text-[14px] text-[#777587]">location_on</span>
                    <span>{member.location}</span>
                  </div>
                </div>

                {/* Assigned Projects pills */}
                <div className="mt-3">
                  <span className="text-[10px] uppercase font-bold text-[#777587] block mb-1.5">
                    Assigned Initiatives
                  </span>
                  <div className="flex flex-wrap gap-1">
                    {memberProjects.map((p) => (
                      <span
                        key={p.id}
                        className="font-mono text-[10px] font-semibold bg-[#e2dfff] text-[#3525cd] px-2 py-0.5 rounded"
                      >
                        {p.code}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Workload Capacity Bar & Stats Footer */}
              <div className="pt-4 border-t border-[#c7c4d8]/20 mt-4 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-[#777587]">
                    Workload Capacity: <strong className="text-[#0b1c30]">{member.assignedTasksCount} tasks</strong>
                  </span>
                  <span
                    className={`font-mono font-bold ${
                      member.capacityPercentage > 90 ? 'text-[#ba1a1a]' : 'text-[#006c49]'
                    }`}
                  >
                    {member.capacityPercentage}%
                  </span>
                </div>

                <div className="w-full bg-[#e5eeff] rounded-full h-1.5 overflow-hidden">
                  <div
                    className={`h-1.5 rounded-full transition-all duration-300 ${
                      member.capacityPercentage > 90 ? 'bg-[#ba1a1a]' : 'bg-[#3525cd]'
                    }`}
                    style={{ width: `${member.capacityPercentage}%` }}
                  />
                </div>

                <div className="flex items-center justify-between pt-1">
                  <button
                    onClick={() => setCurrentView('tasks')}
                    className="text-[11px] font-semibold text-[#3525cd] hover:underline"
                  >
                    View Tasks →
                  </button>
                  <button
                    onClick={() => setCurrentView('messages')}
                    className="text-[11px] font-semibold text-[#464555] hover:text-[#0b1c30] flex items-center gap-1"
                  >
                    <span className="material-symbols-outlined text-[13px]">chat</span>
                    Direct Message
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
