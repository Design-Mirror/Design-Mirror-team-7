import React from 'react';
import { useApp } from '../../context/AppContext';

export const DashboardView: React.FC = () => {
  const {
    currentUser,
    projects,
    tasks,
    milestones,
    activities,
    setCurrentView,
    openProjectDetails,
    openTaskDetails,
    openCreateModal,
    updateTaskStatus,
  } = useApp();

  const urgentTasks = tasks
    .filter((t) => t.status !== 'done' && (t.priority === 'urgent' || t.priority === 'high'))
    .slice(0, 5);

  const completedTasksCount = tasks.filter((t) => t.status === 'done').length;
  const inProgressTasksCount = tasks.filter((t) => t.status === 'in_progress').length;

  return (
    <div className="space-y-6 animate-in fade-in duration-150">
      {/* Welcome Banner */}
      <div className="bg-[#213145] text-white rounded-2xl p-6 relative overflow-hidden shadow-md">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-white/10 text-[#c3c0ff] text-xs font-semibold mb-2">
              <span className="w-2 h-2 rounded-full bg-[#6cf8bb] animate-pulse"></span>
              Sprint 3: Active • Q3 Launch Countdown
            </div>
            <h1 className="font-headline font-bold text-2xl tracking-tight text-white">
              Welcome back, {currentUser.name}
            </h1>
            <p className="text-sm text-[#c7c4d8] mt-1 max-w-xl">
              You have {urgentTasks.length} high-priority tasks requiring review across 3 active projects. College Event App is on track for the October 1 release milestone.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setCurrentView('tasks')}
              className="px-4 py-2 bg-white/10 hover:bg-white/15 text-white text-xs font-semibold rounded-lg border border-white/20 transition-all cursor-pointer"
            >
              View Kanban Board
            </button>
            <button
              onClick={() => openCreateModal('task')}
              className="px-4 py-2 bg-[#4f46e5] hover:bg-[#3525cd] text-white text-xs font-semibold rounded-lg transition-all shadow-sm flex items-center gap-1.5 cursor-pointer"
            >
              <span className="material-symbols-outlined text-[16px]">add</span>
              <span>+ Create Task</span>
            </button>
          </div>
        </div>
      </div>

      {/* Metric Cards Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-[#c7c4d8]/40 shadow-xs">
          <div className="flex items-center justify-between text-[#777587] mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Overall Velocity</span>
            <span className="material-symbols-outlined text-[18px] text-[#3525cd]">speed</span>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-headline text-[#0b1c30]">78%</span>
            <span className="text-xs font-bold text-[#006c49] flex items-center">
              <span className="material-symbols-outlined text-[14px]">trending_up</span> +12% vs last sprint
            </span>
          </div>
          <div className="w-full bg-[#e5eeff] rounded-full h-1.5 mt-3 overflow-hidden">
            <div className="bg-[#3525cd] h-1.5 rounded-full" style={{ width: '78%' }} />
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-[#c7c4d8]/40 shadow-xs">
          <div className="flex items-center justify-between text-[#777587] mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Completed Tasks</span>
            <span className="material-symbols-outlined text-[18px] text-[#006c49]">task_alt</span>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-headline text-[#0b1c30]">
              {completedTasksCount}
            </span>
            <span className="text-xs text-[#777587]">of {tasks.length} total</span>
          </div>
          <p className="text-[11px] text-[#777587] mt-2 flex items-center gap-1">
            <span className="font-semibold text-[#3525cd]">{inProgressTasksCount}</span> currently in active development
          </p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-[#c7c4d8]/40 shadow-xs">
          <div className="flex items-center justify-between text-[#777587] mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Milestones Scoped</span>
            <span className="material-symbols-outlined text-[18px] text-[#684000]">flag</span>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-headline text-[#0b1c30]">5 of 6</span>
            <span className="text-xs font-semibold px-1.5 py-0.2 rounded bg-[#ffddb8] text-[#684000]">
              1 At Risk
            </span>
          </div>
          <p className="text-[11px] text-[#777587] mt-2">
            Oct 1 Release: Payment Gateway pending approval
          </p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-[#c7c4d8]/40 shadow-xs">
          <div className="flex items-center justify-between text-[#777587] mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Team Capacity</span>
            <span className="material-symbols-outlined text-[18px] text-[#3525cd]">group</span>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-headline text-[#0b1c30]">82%</span>
            <span className="text-xs font-semibold px-1.5 py-0.2 rounded bg-[#e2dfff] text-[#3525cd]">
              Optimal Load
            </span>
          </div>
          <p className="text-[11px] text-[#777587] mt-2">
            5 Core Engineers active across 3 repos
          </p>
        </div>
      </div>

      {/* Main Two-Column Dashboard Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Columns: Active Projects & Sprint Highlights */}
        <div className="lg:col-span-2 space-y-6">
          {/* Active Projects Showcase */}
          <div className="bg-white p-5 rounded-xl border border-[#c7c4d8]/40 shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-headline font-bold text-sm text-[#0b1c30]">Active Projects</h3>
                <p className="text-xs text-[#777587]">Core initiatives connected to company OKRs</p>
              </div>
              <button
                onClick={() => setCurrentView('projects')}
                className="text-xs font-semibold text-[#3525cd] hover:underline"
              >
                View All Projects →
              </button>
            </div>

            <div className="space-y-3">
              {projects.map((proj) => (
                <div
                  key={proj.id}
                  onClick={() => openProjectDetails(proj.id)}
                  className="p-4 rounded-xl border border-[#c7c4d8]/30 hover:border-[#3525cd]/60 hover:bg-[#f8f9ff] transition-all cursor-pointer group"
                >
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <div className="flex items-center gap-2.5">
                      <span className="font-mono text-xs font-bold text-[#3525cd] bg-[#e2dfff] px-2 py-0.5 rounded">
                        {proj.code}
                      </span>
                      <h4 className="font-headline font-bold text-sm text-[#0b1c30] group-hover:text-[#3525cd] transition-colors">
                        {proj.name}
                      </h4>
                    </div>
                    <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-[#eff4ff] text-[#3525cd] border border-[#c7c4d8]/30">
                      {proj.deadlineLabel}
                    </span>
                  </div>

                  <p className="text-xs text-[#464555] line-clamp-2 mb-3">
                    {proj.description}
                  </p>

                  <div className="flex items-center justify-between text-xs text-[#777587]">
                    <div className="flex items-center gap-3">
                      <span>Tasks: {proj.completedTasks}/{proj.totalTasks}</span>
                      <span>•</span>
                      <span className="font-semibold text-[#006c49]">{proj.progressPercentage}% Completed</span>
                    </div>

                    <div className="flex -space-x-1.5">
                      {proj.assigneeIds.map((id, idx) => (
                        <div
                          key={idx}
                          className="w-5 h-5 rounded-full border-2 border-white bg-[#e2dfff] text-[#3525cd] text-[9px] font-bold flex items-center justify-center font-mono"
                        >
                          {id.slice(-2).toUpperCase()}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="w-full bg-[#e5eeff] rounded-full h-2 mt-3 overflow-hidden">
                    <div
                      className="bg-[#3525cd] h-2 rounded-full transition-all duration-300"
                      style={{ width: `${proj.progressPercentage}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Current Sprint Milestones Tracker */}
          <div className="bg-white p-5 rounded-xl border border-[#c7c4d8]/40 shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-headline font-bold text-sm text-[#0b1c30]">
                  Sprint Roadmap &amp; Milestones
                </h3>
                <p className="text-xs text-[#777587]">Delivery track for College Event App</p>
              </div>
              <button
                onClick={() => setCurrentView('goals')}
                className="text-xs font-semibold text-[#3525cd] hover:underline"
              >
                Full Roadmap →
              </button>
            </div>

            <div className="space-y-2.5">
              {milestones.slice(0, 4).map((ms) => (
                <div
                  key={ms.id}
                  className="flex items-center justify-between p-3 rounded-lg bg-[#f8f9ff] border border-[#c7c4d8]/20"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ${
                        ms.status === 'completed'
                          ? 'bg-[#6cf8bb]/30 text-[#00714d]'
                          : ms.status === 'in_progress'
                          ? 'bg-[#3525cd] text-white'
                          : 'bg-[#e5eeff] text-[#777587]'
                      }`}
                    >
                      {ms.status === 'completed' ? (
                        <span className="material-symbols-outlined text-[16px]">check</span>
                      ) : (
                        ms.number
                      )}
                    </div>
                    <div>
                      <h5 className="font-semibold text-xs text-[#0b1c30]">{ms.title}</h5>
                      <span className="text-[11px] text-[#777587]">
                        Owner: {ms.ownerName} • Target: {ms.deadline}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    {ms.isAtRisk && (
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#ffdad6] text-[#ba1a1a]">
                        Risk
                      </span>
                    )}
                    <span
                      className={`text-xs font-bold font-mono ${
                        ms.progressPercentage === 100
                          ? 'text-[#006c49]'
                          : 'text-[#3525cd]'
                      }`}
                    >
                      {ms.progressPercentage}%
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right 1 Column: Urgent Tasks & Real-Time Activity Feed */}
        <div className="space-y-6">
          {/* Urgent Tasks */}
          <div className="bg-white p-5 rounded-xl border border-[#c7c4d8]/40 shadow-xs">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-headline font-bold text-sm text-[#0b1c30] flex items-center gap-1.5">
                <span className="material-symbols-outlined text-[#ba1a1a] text-[18px]">emergency</span>
                Urgent Action Items
              </h3>
              <button
                onClick={() => setCurrentView('tasks')}
                className="text-xs text-[#3525cd] font-semibold hover:underline"
              >
                Board
              </button>
            </div>

            <div className="space-y-2">
              {urgentTasks.map((t) => (
                <div
                  key={t.id}
                  className="p-3 rounded-lg border border-[#c7c4d8]/30 hover:bg-[#eff4ff]/60 transition-colors flex items-start gap-2.5 group"
                >
                  <input
                    type="checkbox"
                    checked={t.status === 'done'}
                    onChange={() => updateTaskStatus(t.id, t.status === 'done' ? 'todo' : 'done')}
                    className="mt-0.5 rounded text-[#3525cd] focus:ring-[#3525cd] cursor-pointer"
                  />
                  <div
                    onClick={() => openTaskDetails(t.id)}
                    className="flex-1 min-w-0 cursor-pointer"
                  >
                    <div className="flex items-center gap-1.5 mb-1">
                      <span className="font-mono text-[10px] text-[#777587]">{t.code}</span>
                      <span
                        className={`text-[9px] font-bold uppercase px-1.5 py-0.2 rounded ${
                          t.priority === 'urgent'
                            ? 'bg-[#ffdad6] text-[#ba1a1a]'
                            : 'bg-[#ffddb8] text-[#684000]'
                        }`}
                      >
                        {t.priority}
                      </span>
                    </div>
                    <p className="text-xs font-semibold text-[#0b1c30] leading-tight truncate group-hover:text-[#3525cd]">
                      {t.title}
                    </p>
                    <span className="text-[10px] text-[#ba1a1a] font-medium block mt-1">
                      {t.dueLabel || t.dueDate}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Real-time Team Activity Feed */}
          <div className="bg-white p-5 rounded-xl border border-[#c7c4d8]/40 shadow-xs">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-headline font-bold text-sm text-[#0b1c30] flex items-center gap-1.5">
                <span className="material-symbols-outlined text-[#3525cd] text-[18px]">history</span>
                Workspace Activity
              </h3>
            </div>

            <div className="space-y-3 divide-y divide-[#c7c4d8]/15">
              {activities.slice(0, 5).map((act) => (
                <div key={act.id} className="pt-2.5 first:pt-0 flex items-start gap-2.5">
                  <img
                    src={act.userAvatar}
                    alt={act.userName}
                    className="w-6 h-6 rounded-full object-cover shrink-0 mt-0.5"
                  />
                  <div className="flex-1 min-w-0 text-xs">
                    <p className="text-[#0b1c30] leading-snug">
                      <span className="font-bold">{act.userName}</span>{' '}
                      <span className="text-[#777587]">{act.action}</span>{' '}
                      <span className="font-semibold text-[#3525cd] truncate">{act.target}</span>
                    </p>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-[10px] text-[#777587] font-mono">{act.timeAgo}</span>
                      <span className="text-[10px] px-1.5 py-0.2 rounded bg-[#eff4ff] text-[#464555]">
                        {act.category}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
