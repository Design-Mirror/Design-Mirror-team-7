import React from 'react';
import { useApp } from '../../context/AppContext';
import { ViewType } from '../../types';

interface NavItem {
  id: ViewType;
  label: string;
  icon: string;
  badge?: number;
}

export const SideNavBar: React.FC<{
  isMobileOpen?: boolean;
  onCloseMobile?: () => void;
}> = ({ isMobileOpen, onCloseMobile }) => {
  const { currentView, setCurrentView, currentUser, openCreateModal, notifications } = useApp();

  const unreadCount = notifications.filter((n) => !n.read).length;

  const navItems: NavItem[] = [
    { id: 'dashboard', label: 'Dashboard', icon: 'dashboard' },
    { id: 'projects', label: 'Projects', icon: 'folder_open' },
    { id: 'tasks', label: 'My Tasks', icon: 'check_circle' },
    { id: 'goals', label: 'Goals & Milestones', icon: 'flag' },
    { id: 'team', label: 'Team', icon: 'group' },
    { id: 'reports', label: 'Reports', icon: 'bar_chart' },
    { id: 'files', label: 'Files', icon: 'attach_file' },
    { id: 'messages', label: 'Messages', icon: 'chat_bubble' },
    { id: 'notifications', label: 'Notifications', icon: 'notifications', badge: unreadCount },
  ];

  const handleNavClick = (id: ViewType) => {
    setCurrentView(id);
    if (onCloseMobile) onCloseMobile();
  };

  return (
    <>
      {/* Mobile backdrop */}
      {isMobileOpen && (
        <div
          onClick={onCloseMobile}
          className="fixed inset-0 bg-black/50 z-40 md:hidden backdrop-blur-xs transition-opacity"
        />
      )}

      <aside
        id="side-navigation"
        className={`h-screen w-60 fixed left-0 top-0 flex flex-col justify-between shrink-0 bg-[#213145] border-r border-[#c7c4d8]/20 z-40 select-none transition-transform duration-200 ease-in-out ${
          isMobileOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        }`}
      >
        <div className="w-60 h-full flex flex-col p-4 justify-between">
          <div className="flex flex-col gap-5">
            {/* Brand Header */}
            <div className="flex items-center justify-between px-1 pt-1">
              <div
                onClick={() => handleNavClick('dashboard')}
                className="flex items-center gap-3 cursor-pointer group"
              >
                <div className="w-8 h-8 rounded-lg bg-[#4f46e5] flex items-center justify-center text-white shadow-sm group-hover:scale-105 transition-transform">
                  <span className="material-symbols-outlined text-[18px]">terminal</span>
                </div>
                <div className="flex flex-col">
                  <span className="font-headline font-bold text-[18px] text-white tracking-tight leading-none">
                    Manage
                  </span>
                  <span className="text-[11px] font-medium text-[#c7c4d8] mt-0.5">
                    Product Engineering
                  </span>
                </div>
              </div>

              {/* Close button on mobile */}
              {onCloseMobile && (
                <button
                  onClick={onCloseMobile}
                  className="md:hidden text-[#c7c4d8] hover:text-white p-1"
                >
                  <span className="material-symbols-outlined text-[20px]">close</span>
                </button>
              )}
            </div>

            {/* Quick Action CTA Button */}
            <button
              id="sidebar-create-item-btn"
              onClick={() => openCreateModal('task')}
              className="w-full bg-[#4f46e5] hover:bg-[#3525cd] text-white text-xs font-semibold py-2 px-3 rounded-lg flex items-center justify-center gap-2 transition-all duration-150 shadow-sm active:scale-[0.98] cursor-pointer"
            >
              <span className="material-symbols-outlined text-[16px]">add</span>
              <span>+ Create Item</span>
            </button>

            {/* Navigation items list */}
            <nav className="flex flex-col gap-1 overflow-y-auto max-h-[calc(100vh-270px)] pr-1 custom-scrollbar">
              {navItems.map((item) => {
                const isActive =
                  currentView === item.id ||
                  (item.id === 'projects' && currentView === 'project-details');

                return (
                  <button
                    key={item.id}
                    id={`nav-item-${item.id}`}
                    onClick={() => handleNavClick(item.id)}
                    className={`flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-colors duration-150 cursor-pointer text-left w-full ${
                      isActive
                        ? 'bg-white/15 text-white shadow-xs font-semibold'
                        : 'text-[#c7c4d8] hover:text-white hover:bg-white/10'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <span
                        className={`material-symbols-outlined text-[18px] ${
                          isActive ? 'text-[#c3c0ff] fill-1' : 'text-[#c7c4d8]'
                        }`}
                      >
                        {item.icon}
                      </span>
                      <span>{item.label}</span>
                    </div>

                    {item.badge !== undefined && item.badge > 0 && (
                      <span className="px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-[#4f46e5] text-white">
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Footer Navigation */}
          <div className="border-t border-[#c7c4d8]/15 pt-3 flex flex-col gap-1">
            <button
              id="sidebar-workspace-settings-btn"
              onClick={() => handleNavClick('settings')}
              className={`flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-medium transition-colors duration-150 w-full text-left cursor-pointer ${
                currentView === 'settings'
                  ? 'bg-white/15 text-white font-semibold'
                  : 'text-[#c7c4d8] hover:text-white hover:bg-white/10'
              }`}
            >
              <span className="material-symbols-outlined text-[18px]">settings</span>
              <span>Workspace Settings</span>
            </button>

            {/* User Profile Pill */}
            <div
              id="sidebar-user-profile-pill"
              onClick={() => handleNavClick('settings')}
              className="flex items-center gap-3 px-3 py-2 rounded-lg text-white hover:bg-white/10 transition-colors duration-150 cursor-pointer"
            >
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                className="w-7 h-7 rounded-full object-cover border border-[#c7c4d8]/40 shrink-0"
              />
              <div className="flex flex-col truncate">
                <span className="text-xs font-semibold truncate text-white">
                  {currentUser.name} (Admin)
                </span>
                <span className="text-[11px] text-[#c7c4d8] truncate font-mono">
                  {currentUser.email}
                </span>
              </div>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};
