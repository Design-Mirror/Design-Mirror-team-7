import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../context/AppContext';

export const TopNavBar: React.FC<{
  onOpenMobileMenu?: () => void;
}> = ({ onOpenMobileMenu }) => {
  const {
    currentUser,
    setIsCommandPaletteOpen,
    openCreateModal,
    notifications,
    markNotificationAsRead,
    setCurrentView,
    openTaskDetails,
  } = useApp();

  const [isNotifOpen, setIsNotifOpen] = useState(false);
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
  const notifRef = useRef<HTMLDivElement>(null);
  const profileRef = useRef<HTMLDivElement>(null);

  const unreadCount = notifications.filter((n) => !n.read).length;

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) {
        setIsNotifOpen(false);
      }
      if (profileRef.current && !profileRef.current.contains(e.target as Node)) {
        setIsProfileMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header
      id="top-navbar"
      className="docked full-width top-0 sticky z-30 bg-white border-b border-[#c7c4d8]/30 h-12 flex items-center justify-between px-4 sm:px-6 w-full shrink-0"
    >
      {/* Left side: Mobile hamburger + Search / Workspace context */}
      <div className="flex items-center gap-3 flex-1 max-w-lg">
        {/* Mobile menu trigger */}
        <button
          id="mobile-menu-button"
          onClick={onOpenMobileMenu}
          className="md:hidden p-1.5 rounded-lg text-[#464555] hover:text-[#0b1c30] hover:bg-[#eff4ff] transition-colors"
          aria-label="Open mobile menu"
        >
          <span className="material-symbols-outlined text-[20px]">menu</span>
        </button>

        {/* Global Search trigger (Command Palette) */}
        <div
          id="search-trigger-container"
          onClick={() => setIsCommandPaletteOpen(true)}
          className="relative w-full max-w-xs sm:max-w-sm flex items-center cursor-pointer group"
        >
          <span className="material-symbols-outlined absolute left-2.5 text-[#777587] text-[16px] group-hover:text-[#3525cd] transition-colors">
            search
          </span>
          <input
            type="text"
            readOnly
            placeholder="Search tasks, milestones, documents..."
            className="w-full pl-8 pr-16 py-1 bg-[#f8f9ff] hover:bg-[#eff4ff] rounded-lg border border-[#c7c4d8]/50 text-xs text-[#0b1c30] placeholder:text-[#777587]/70 cursor-pointer transition-colors focus:outline-none"
          />
          <span className="absolute right-2 text-[10px] font-mono text-[#777587] border border-[#c7c4d8]/60 rounded px-1.5 py-0.5 bg-white shadow-2xs">
            ⌘K Search
          </span>
        </div>
      </div>

      {/* Right side: Quick Actions & Profile */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* + New Button */}
        <button
          id="top-nav-new-btn"
          onClick={() => openCreateModal('task')}
          className="bg-[#4f46e5] hover:bg-[#3525cd] text-white text-xs font-semibold px-3 py-1 rounded-lg flex items-center gap-1.5 transition-all shadow-xs active:scale-[0.98] cursor-pointer"
        >
          <span className="material-symbols-outlined text-[15px]">add</span>
          <span>+ New</span>
        </button>

        <div className="h-4 w-px bg-[#c7c4d8]/30 mx-0.5 sm:mx-1"></div>

        {/* Notifications Popover Trigger */}
        <div className="relative" ref={notifRef}>
          <button
            id="notifications-popover-btn"
            onClick={() => setIsNotifOpen((prev) => !prev)}
            aria-label="Notifications"
            className="p-1.5 text-[#464555] hover:text-[#0b1c30] rounded-lg hover:bg-[#eff4ff] transition-colors relative cursor-pointer"
          >
            <span className="material-symbols-outlined text-[20px]">notifications</span>
            {unreadCount > 0 && (
              <span className="w-2 h-2 rounded-full bg-[#4f46e5] absolute top-1.5 right-1.5 ring-2 ring-white"></span>
            )}
          </button>

          {/* Notifications Dropdown Panel */}
          {isNotifOpen && (
            <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white border border-[#c7c4d8]/40 rounded-xl shadow-xl z-50 overflow-hidden animate-in fade-in slide-in-from-top-1 duration-150">
              <div className="p-3 border-b border-[#c7c4d8]/20 flex items-center justify-between bg-[#f8f9ff]">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-[#0b1c30]">Notifications</span>
                  {unreadCount > 0 && (
                    <span className="px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-[#4f46e5] text-white">
                      {unreadCount} new
                    </span>
                  )}
                </div>
                <button
                  onClick={() => {
                    setIsNotifOpen(false);
                    setCurrentView('notifications');
                  }}
                  className="text-[11px] text-[#3525cd] hover:underline font-semibold"
                >
                  View All
                </button>
              </div>

              <div className="max-h-72 overflow-y-auto divide-y divide-[#c7c4d8]/15 custom-scrollbar">
                {notifications.slice(0, 5).map((notif) => (
                  <div
                    key={notif.id}
                    onClick={() => {
                      markNotificationAsRead(notif.id);
                      if (notif.linkAction?.view) {
                        setCurrentView(notif.linkAction.view);
                        if (notif.linkAction.id && notif.linkAction.view === 'tasks') {
                          openTaskDetails(notif.linkAction.id);
                        }
                      }
                      setIsNotifOpen(false);
                    }}
                    className={`p-3 text-left hover:bg-[#eff4ff]/60 transition-colors cursor-pointer flex gap-3 items-start ${
                      !notif.read ? 'bg-[#eff4ff]/30' : ''
                    }`}
                  >
                    <span className="w-2 h-2 rounded-full bg-[#3525cd] mt-1.5 shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-semibold text-[#0b1c30] truncate">
                        {notif.title}
                      </p>
                      <p className="text-[11px] text-[#464555] line-clamp-2 mt-0.5">
                        {notif.description}
                      </p>
                      <span className="text-[10px] font-mono text-[#777587] mt-1 block">
                        {notif.timestamp}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Help Button */}
        <button
          id="help-button"
          onClick={() => setIsCommandPaletteOpen(true)}
          aria-label="Help"
          className="p-1.5 text-[#464555] hover:text-[#0b1c30] rounded-lg hover:bg-[#eff4ff] transition-colors cursor-pointer"
          title="Command Palette & Help (⌘K)"
        >
          <span className="material-symbols-outlined text-[20px]">help_outline</span>
        </button>

        {/* Profile Avatar & Dropdown */}
        <div className="relative pl-1" ref={profileRef}>
          <div
            id="profile-dropdown-btn"
            onClick={() => setIsProfileMenuOpen((prev) => !prev)}
            className="flex items-center gap-1 cursor-pointer"
          >
            <img
              src={currentUser.avatar}
              alt={currentUser.name}
              className="w-7 h-7 rounded-full object-cover border border-[#c7c4d8]/40 hover:ring-2 hover:ring-[#4f46e5]/40 transition-all"
            />
          </div>

          {isProfileMenuOpen && (
            <div className="absolute right-0 mt-2 w-56 bg-white border border-[#c7c4d8]/40 rounded-xl shadow-xl z-50 p-2 text-xs">
              <div className="px-3 py-2 border-b border-[#c7c4d8]/20 mb-1">
                <span className="font-bold text-[#0b1c30] block">{currentUser.name}</span>
                <span className="text-[11px] text-[#777587] font-mono block">{currentUser.email}</span>
                <span className="inline-block mt-1 px-1.5 py-0.2 rounded text-[10px] font-semibold bg-[#6cf8bb]/30 text-[#00714d]">
                  ● {currentUser.availability}
                </span>
              </div>
              <button
                onClick={() => {
                  setCurrentView('settings');
                  setIsProfileMenuOpen(false);
                }}
                className="w-full text-left px-3 py-1.5 rounded-lg text-[#0b1c30] hover:bg-[#eff4ff] flex items-center gap-2"
              >
                <span className="material-symbols-outlined text-[16px]">person</span>
                Profile Settings
              </button>
              <button
                onClick={() => {
                  setCurrentView('tasks');
                  setIsProfileMenuOpen(false);
                }}
                className="w-full text-left px-3 py-1.5 rounded-lg text-[#0b1c30] hover:bg-[#eff4ff] flex items-center gap-2"
              >
                <span className="material-symbols-outlined text-[16px]">check_circle</span>
                My Assigned Tasks
              </button>
              <button
                onClick={() => {
                  setCurrentView('settings');
                  setIsProfileMenuOpen(false);
                }}
                className="w-full text-left px-3 py-1.5 rounded-lg text-[#0b1c30] hover:bg-[#eff4ff] flex items-center gap-2"
              >
                <span className="material-symbols-outlined text-[16px]">tune</span>
                Preferences
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
