import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { ViewType } from '../../types';

export const CommandPalette: React.FC = () => {
  const {
    isCommandPaletteOpen,
    setIsCommandPaletteOpen,
    setCurrentView,
    tasks,
    projects,
    goals,
    openTaskDetails,
    openProjectDetails,
    openCreateModal,
  } = useApp();

  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isCommandPaletteOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
      setQuery('');
    }
  }, [isCommandPaletteOpen]);

  if (!isCommandPaletteOpen) return null;

  const filteredTasks = tasks.filter(
    (t) =>
      t.title.toLowerCase().includes(query.toLowerCase()) ||
      t.code.toLowerCase().includes(query.toLowerCase())
  );

  const filteredProjects = projects.filter(
    (p) =>
      p.name.toLowerCase().includes(query.toLowerCase()) ||
      p.code.toLowerCase().includes(query.toLowerCase())
  );

  const allNavOptions: { id: ViewType; label: string; icon: string; category: string }[] = [
    { id: 'dashboard', label: 'Go to Dashboard', icon: 'dashboard', category: 'Navigation' },
    { id: 'projects', label: 'Go to Projects', icon: 'folder_open', category: 'Navigation' },
    { id: 'tasks', label: 'Go to Tasks & Kanban Board', icon: 'check_circle', category: 'Navigation' },
    { id: 'goals', label: 'Go to Goals & Milestones', icon: 'flag', category: 'Navigation' },
    { id: 'team', label: 'Go to Team Directory', icon: 'group', category: 'Navigation' },
    { id: 'reports', label: 'Go to Reports & Analytics', icon: 'bar_chart', category: 'Navigation' },
    { id: 'files', label: 'Go to Files', icon: 'attach_file', category: 'Navigation' },
    { id: 'messages', label: 'Go to Team Messages', icon: 'chat_bubble', category: 'Navigation' },
    { id: 'notifications', label: 'Go to Notifications', icon: 'notifications', category: 'Navigation' },
    { id: 'settings', label: 'Go to Workspace Settings', icon: 'settings', category: 'Navigation' },
  ];

  const navigationOptions = allNavOptions.filter((item) =>
    item.label.toLowerCase().includes(query.toLowerCase())
  );

  const handleSelectNav = (view: ViewType) => {
    setCurrentView(view);
    setIsCommandPaletteOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 px-4 bg-black/50 backdrop-blur-xs">
      <div
        className="w-full max-w-2xl bg-white rounded-xl shadow-2xl border border-[#c7c4d8]/40 overflow-hidden animate-in fade-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input Bar */}
        <div className="flex items-center px-4 py-3 border-b border-[#c7c4d8]/30 gap-3 bg-[#f8f9ff]">
          <span className="material-symbols-outlined text-[#777587] text-[20px]">search</span>
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Type a command, search tasks, projects, or milestones..."
            className="w-full bg-transparent text-sm text-[#0b1c30] placeholder:text-[#777587] outline-none font-medium"
          />
          <kbd className="px-2 py-0.5 text-[10px] font-mono text-[#777587] bg-white border border-[#c7c4d8]/50 rounded shadow-xs">
            ESC
          </kbd>
        </div>

        {/* Results Container */}
        <div className="max-h-96 overflow-y-auto p-2 divide-y divide-[#c7c4d8]/15 custom-scrollbar text-xs">
          {/* Quick Actions */}
          <div className="py-2">
            <span className="px-3 text-[10px] font-bold uppercase tracking-wider text-[#777587] block mb-1">
              Quick Actions
            </span>
            <button
              onClick={() => {
                setIsCommandPaletteOpen(false);
                openCreateModal('task');
              }}
              className="w-full text-left px-3 py-2 rounded-lg hover:bg-[#eff4ff] flex items-center justify-between transition-colors cursor-pointer group"
            >
              <div className="flex items-center gap-2.5">
                <span className="material-symbols-outlined text-[16px] text-[#4f46e5]">add_task</span>
                <span className="font-semibold text-[#0b1c30]">Create New Task</span>
              </div>
              <span className="text-[10px] font-mono text-[#777587] group-hover:text-[#4f46e5]">Action</span>
            </button>
            <button
              onClick={() => {
                setIsCommandPaletteOpen(false);
                openCreateModal('project');
              }}
              className="w-full text-left px-3 py-2 rounded-lg hover:bg-[#eff4ff] flex items-center justify-between transition-colors cursor-pointer group"
            >
              <div className="flex items-center gap-2.5">
                <span className="material-symbols-outlined text-[16px] text-[#3525cd]">create_new_folder</span>
                <span className="font-semibold text-[#0b1c30]">Create New Project</span>
              </div>
              <span className="text-[10px] font-mono text-[#777587] group-hover:text-[#3525cd]">Action</span>
            </button>
            <button
              onClick={() => {
                setIsCommandPaletteOpen(false);
                openCreateModal('milestone');
              }}
              className="w-full text-left px-3 py-2 rounded-lg hover:bg-[#eff4ff] flex items-center justify-between transition-colors cursor-pointer group"
            >
              <div className="flex items-center gap-2.5">
                <span className="material-symbols-outlined text-[16px] text-[#006c49]">flag</span>
                <span className="font-semibold text-[#0b1c30]">Add New Milestone</span>
              </div>
              <span className="text-[10px] font-mono text-[#777587] group-hover:text-[#006c49]">Action</span>
            </button>
          </div>

          {/* Filtered Projects */}
          {filteredProjects.length > 0 && (
            <div className="py-2">
              <span className="px-3 text-[10px] font-bold uppercase tracking-wider text-[#777587] block mb-1">
                Projects ({filteredProjects.length})
              </span>
              {filteredProjects.map((p) => (
                <button
                  key={p.id}
                  onClick={() => {
                    openProjectDetails(p.id);
                    setIsCommandPaletteOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 rounded-lg hover:bg-[#eff4ff] flex items-center justify-between transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-2.5">
                    <span className="font-mono font-bold text-[11px] text-[#3525cd] bg-[#e2dfff] px-1.5 py-0.5 rounded">
                      {p.code}
                    </span>
                    <span className="font-semibold text-[#0b1c30]">{p.name}</span>
                  </div>
                  <span className="text-[11px] text-[#006c49] font-bold">{p.progressPercentage}%</span>
                </button>
              ))}
            </div>
          )}

          {/* Filtered Tasks */}
          {filteredTasks.length > 0 && (
            <div className="py-2">
              <span className="px-3 text-[10px] font-bold uppercase tracking-wider text-[#777587] block mb-1">
                Tasks ({filteredTasks.length})
              </span>
              {filteredTasks.slice(0, 6).map((t) => (
                <button
                  key={t.id}
                  onClick={() => {
                    openTaskDetails(t.id);
                    setIsCommandPaletteOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 rounded-lg hover:bg-[#eff4ff] flex items-center justify-between transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span className="font-mono text-[11px] text-[#777587]">{t.code}</span>
                    <span className="font-medium text-[#0b1c30] truncate">{t.title}</span>
                  </div>
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase shrink-0 ${
                      t.priority === 'urgent'
                        ? 'bg-[#ffdad6] text-[#ba1a1a]'
                        : t.priority === 'high'
                        ? 'bg-[#ffddb8] text-[#684000]'
                        : 'bg-[#e5eeff] text-[#464555]'
                    }`}
                  >
                    {t.priority}
                  </span>
                </button>
              ))}
            </div>
          )}

          {/* Navigation links */}
          {navigationOptions.length > 0 && (
            <div className="py-2">
              <span className="px-3 text-[10px] font-bold uppercase tracking-wider text-[#777587] block mb-1">
                Workspace Pages
              </span>
              {navigationOptions.map((opt) => (
                <button
                  key={opt.id}
                  onClick={() => handleSelectNav(opt.id)}
                  className="w-full text-left px-3 py-2 rounded-lg hover:bg-[#eff4ff] flex items-center gap-2.5 transition-colors cursor-pointer text-[#0b1c30]"
                >
                  <span className="material-symbols-outlined text-[16px] text-[#777587]">{opt.icon}</span>
                  <span className="font-medium">{opt.label}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="px-4 py-2 bg-[#f8f9ff] border-t border-[#c7c4d8]/20 flex items-center justify-between text-[11px] text-[#777587]">
          <span>Tip: Press ⌘K anywhere in the workspace to launch</span>
          <button
            onClick={() => setIsCommandPaletteOpen(false)}
            className="hover:text-[#0b1c30] text-[11px] font-medium"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
