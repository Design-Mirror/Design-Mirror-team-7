export type ViewType =
  | 'dashboard'
  | 'projects'
  | 'project-details'
  | 'tasks'
  | 'goals'
  | 'team'
  | 'reports'
  | 'files'
  | 'messages'
  | 'notifications'
  | 'settings';

export type TaskStatus = 'backlog' | 'todo' | 'in_progress' | 'review' | 'done';

export type TaskPriority = 'low' | 'medium' | 'high' | 'urgent';

export interface TeamMember {
  id: string;
  name: string;
  email: string;
  role: string;
  department: string;
  avatar: string;
  initials: string;
  currentProjects: string[];
  assignedTasksCount: number;
  capacityPercentage: number;
  capacityStatus: 'Optimal' | 'High workload' | 'Healthy';
  availability: 'Online' | 'Busy' | 'In Meeting' | 'Offline';
  phone?: string;
  location?: string;
}

export interface ChecklistItem {
  id: string;
  title: string;
  completed: boolean;
}

export interface TaskComment {
  id: string;
  authorId: string;
  authorName: string;
  authorAvatar: string;
  createdAt: string;
  content: string;
}

export interface TaskItem {
  id: string;
  code: string; // e.g. CEA-94
  title: string;
  description: string;
  status: TaskStatus;
  priority: TaskPriority;
  projectId: string;
  projectName: string;
  milestoneId?: string;
  milestoneName?: string;
  assigneeId: string;
  assigneeName: string;
  assigneeAvatar: string;
  dueDate: string;
  dueLabel?: string;
  isOverdue?: boolean;
  checklist: ChecklistItem[];
  comments: TaskComment[];
  attachmentCount: number;
  subtaskCount?: number;
  tags?: string[];
  createdAt: string;
  completedAt?: string;
}

export interface Milestone {
  id: string;
  number: number;
  title: string;
  description: string;
  projectId: string;
  status: 'completed' | 'in_progress' | 'pending';
  progressPercentage: number;
  ownerName: string;
  ownerRole: string;
  ownerAvatar?: string;
  ownerInitials: string;
  deadline: string;
  completedDate?: string;
  tasksCount: number;
  completedTasksCount: number;
  isAtRisk?: boolean;
  riskDescription?: string;
}

export interface CompanyGoal {
  id: string;
  goalNumber: number;
  title: string;
  keyResult: string;
  ownerName: string;
  ownerRole: string;
  deadline: string;
  status: 'On Track' | 'At Risk' | 'Completed';
  velocityPercentage: number;
  milestonesScoped: number;
  totalMilestones: number;
  quarter: string;
  projectIds: string[];
}

export interface Project {
  id: string;
  code: string; // e.g. CEA-2024
  name: string;
  description: string;
  progressPercentage: number;
  status: 'active' | 'in_review' | 'completed' | 'planning';
  priority: TaskPriority;
  deadline: string;
  deadlineLabel?: string;
  totalTasks: number;
  completedTasks: number;
  assigneeIds: string[];
  companyGoalId?: string;
  category: string;
  colorAccent: string;
}

export interface FileItem {
  id: string;
  name: string;
  type: 'pdf' | 'figma' | 'code' | 'doc' | 'archive' | 'image';
  size: string;
  modifiedDate: string;
  projectId: string;
  projectName: string;
  ownerName: string;
  ownerAvatar?: string;
  category: 'Design Specs' | 'Architecture' | 'Contracts' | 'Sprint Assets';
}

export interface MessageItem {
  id: string;
  channelId: string;
  senderId: string;
  senderName: string;
  senderAvatar: string;
  senderRole?: string;
  timestamp: string;
  content: string;
  attachments?: string[];
}

export interface NotificationItem {
  id: string;
  title: string;
  description: string;
  type: 'assignment' | 'deadline' | 'update' | 'activity' | 'system';
  timestamp: string;
  read: boolean;
  avatar?: string;
  linkAction?: {
    view: ViewType;
    id?: string;
  };
}

export interface ActivityItem {
  id: string;
  userName: string;
  userAvatar: string;
  action: string;
  target: string;
  category: 'Completed' | 'New Task' | 'Attachment' | 'Milestone Approved' | 'Update';
  timeAgo: string;
  timestamp: string;
}

export interface ToastMessage {
  id: string;
  type: 'success' | 'info' | 'warning' | 'error';
  title: string;
  message?: string;
}
