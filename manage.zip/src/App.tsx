import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { SideNavBar } from './components/layout/SideNavBar';
import { TopNavBar } from './components/layout/TopNavBar';
import { CommandPalette } from './components/layout/CommandPalette';
import { ToastContainer } from './components/common/ToastContainer';
import { CreateItemModal } from './components/modals/CreateItemModal';
import { TaskDetailsModal } from './components/modals/TaskDetailsModal';

// Views
import { DashboardView } from './components/views/DashboardView';
import { ProjectsView } from './components/views/ProjectsView';
import { ProjectDetailsView } from './components/views/ProjectDetailsView';
import { TaskManagementView } from './components/views/TaskManagementView';
import { GoalsMilestonesView } from './components/views/GoalsMilestonesView';
import { TeamView } from './components/views/TeamView';
import { ReportsView } from './components/views/ReportsView';
import { FilesView } from './components/views/FilesView';
import { MessagesView } from './components/views/MessagesView';
import { NotificationsView } from './components/views/NotificationsView';
import { SettingsView } from './components/views/SettingsView';

const MainLayout: React.FC = () => {
  const { currentView } = useApp();
  const [isMobileNavOpen, setIsMobileNavOpen] = useState(false);

  const renderActiveView = () => {
    switch (currentView) {
      case 'dashboard':
        return <DashboardView />;
      case 'projects':
        return <ProjectsView />;
      case 'project-details':
        return <ProjectDetailsView />;
      case 'tasks':
        return <TaskManagementView />;
      case 'goals':
        return <GoalsMilestonesView />;
      case 'team':
        return <TeamView />;
      case 'reports':
        return <ReportsView />;
      case 'files':
        return <FilesView />;
      case 'messages':
        return <MessagesView />;
      case 'notifications':
        return <NotificationsView />;
      case 'settings':
        return <SettingsView />;
      default:
        return <DashboardView />;
    }
  };

  return (
    <div className="min-h-screen bg-[#f8f9ff] flex text-[#0b1c30]">
      {/* Side Navigation Bar (desktop 60 = 240px wide, mobile slide-in) */}
      <SideNavBar
        isMobileOpen={isMobileNavOpen}
        onCloseMobile={() => setIsMobileNavOpen(false)}
      />

      {/* Main Content Column */}
      <div className="flex-1 flex flex-col min-w-0 md:ml-60">
        {/* Top Navbar */}
        <TopNavBar onOpenMobileMenu={() => setIsMobileNavOpen(true)} />

        {/* Scrollable Page Body */}
        <main className="flex-1 p-4 sm:p-6 max-w-7xl w-full mx-auto">
          {renderActiveView()}
        </main>
      </div>

      {/* Global Modals & Overlays */}
      <CommandPalette />
      <CreateItemModal />
      <TaskDetailsModal />
      <ToastContainer />
    </div>
  );
};

export function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}

export default App;
