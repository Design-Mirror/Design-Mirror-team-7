import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  ViewType,
  Project,
  TaskItem,
  TaskStatus,
  Milestone,
  CompanyGoal,
  TeamMember,
  FileItem,
  MessageItem,
  NotificationItem,
  ActivityItem,
  ToastMessage,
} from '../types';
import {
  CURRENT_USER,
  INITIAL_TEAM_MEMBERS,
  INITIAL_PROJECTS,
  INITIAL_GOALS,
  INITIAL_MILESTONES,
  INITIAL_TASKS,
  INITIAL_FILES,
  INITIAL_MESSAGES,
  INITIAL_NOTIFICATIONS,
  INITIAL_ACTIVITIES,
} from '../data/mockData';

interface AppContextType {
  currentUser: TeamMember;
  currentView: ViewType;
  setCurrentView: (view: ViewType) => void;
  selectedProjectId: string;
  setSelectedProjectId: (id: string) => void;
  selectedTaskId: string | null;
  setSelectedTaskId: (id: string | null) => void;
  openTaskDetails: (taskOrId: TaskItem | string) => void;
  closeTaskDetails: () => void;
  openProjectDetails: (projectId: string) => void;

  projects: Project[];
  tasks: TaskItem[];
  goals: CompanyGoal[];
  milestones: Milestone[];
  teamMembers: TeamMember[];
  files: FileItem[];
  messages: MessageItem[];
  notifications: NotificationItem[];
  activities: ActivityItem[];
  toasts: ToastMessage[];

  isCommandPaletteOpen: boolean;
  setIsCommandPaletteOpen: (open: boolean) => void;
  isCreateItemModalOpen: boolean;
  setIsCreateItemModalOpen: (open: boolean) => void;
  createItemDefaultTab: 'task' | 'project' | 'goal' | 'milestone';
  setCreateItemDefaultTab: (tab: 'task' | 'project' | 'goal' | 'milestone') => void;
  openCreateModal: (tab?: 'task' | 'project' | 'goal' | 'milestone') => void;

  searchQuery: string;
  setSearchQuery: (q: string) => void;

  addToast: (toast: Omit<ToastMessage, 'id'>) => void;
  removeToast: (id: string) => void;

  addProject: (newProj: Partial<Project> & { name: string; description: string }) => void;
  addTask: (newTask: Partial<TaskItem> & { title: string; projectId: string }) => void;
  updateTaskStatus: (taskId: string, status: TaskStatus) => void;
  toggleTaskChecklist: (taskId: string, checklistId: string) => void;
  addTaskComment: (taskId: string, content: string) => void;
  addGoal: (newGoal: Partial<CompanyGoal> & { title: string; keyResult: string }) => void;
  addMilestone: (newMs: Partial<Milestone> & { title: string; projectId: string }) => void;
  sendMessage: (channelId: string, content: string) => void;
  markNotificationAsRead: (id: string) => void;
  markAllNotificationsAsRead: () => void;
  addFile: (newFile: Partial<FileItem> & { name: string; size: string }) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser] = useState<TeamMember>(CURRENT_USER);
  const [currentView, setCurrentView] = useState<ViewType>('dashboard');
  const [selectedProjectId, setSelectedProjectId] = useState<string>('cea-2024');
  const [selectedTaskId, setSelectedTaskId] = useState<string | null>(null);

  const [projects, setProjects] = useState<Project[]>(INITIAL_PROJECTS);
  const [tasks, setTasks] = useState<TaskItem[]>(INITIAL_TASKS);
  const [goals, setGoals] = useState<CompanyGoal[]>(INITIAL_GOALS);
  const [milestones, setMilestones] = useState<Milestone[]>(INITIAL_MILESTONES);
  const [teamMembers] = useState<TeamMember[]>(INITIAL_TEAM_MEMBERS);
  const [files, setFiles] = useState<FileItem[]>(INITIAL_FILES);
  const [messages, setMessages] = useState<MessageItem[]>(INITIAL_MESSAGES);
  const [notifications, setNotifications] = useState<NotificationItem[]>(INITIAL_NOTIFICATIONS);
  const [activities, setActivities] = useState<ActivityItem[]>(INITIAL_ACTIVITIES);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState(false);
  const [isCreateItemModalOpen, setIsCreateItemModalOpen] = useState(false);
  const [createItemDefaultTab, setCreateItemDefaultTab] = useState<'task' | 'project' | 'goal' | 'milestone'>('task');
  const [searchQuery, setSearchQuery] = useState('');

  // Global Keyboard shortcut for Command Palette ⌘K or Ctrl+K
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsCommandPaletteOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const addToast = (toast: Omit<ToastMessage, 'id'>) => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const newToast: ToastMessage = { ...toast, id };
    setToasts((prev) => [...prev, newToast]);

    setTimeout(() => {
      removeToast(id);
    }, 4000);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const openTaskDetails = (taskOrId: TaskItem | string) => {
    const id = typeof taskOrId === 'string' ? taskOrId : taskOrId.id;
    setSelectedTaskId(id);
  };

  const closeTaskDetails = () => {
    setSelectedTaskId(null);
  };

  const openProjectDetails = (projId: string) => {
    setSelectedProjectId(projId);
    setCurrentView('project-details');
  };

  const openCreateModal = (tab: 'task' | 'project' | 'goal' | 'milestone' = 'task') => {
    setCreateItemDefaultTab(tab);
    setIsCreateItemModalOpen(true);
  };

  const addProject = (newProj: Partial<Project> & { name: string; description: string }) => {
    const code = `PRJ-${Math.floor(100 + Math.random() * 900)}`;
    const id = `proj-${Date.now()}`;
    const project: Project = {
      id,
      code,
      name: newProj.name,
      description: newProj.description,
      progressPercentage: 0,
      status: 'active',
      priority: newProj.priority || 'medium',
      deadline: newProj.deadline || '2024-11-30',
      deadlineLabel: newProj.deadlineLabel || 'Nov 30',
      totalTasks: 0,
      completedTasks: 0,
      assigneeIds: newProj.assigneeIds || [currentUser.id],
      companyGoalId: newProj.companyGoalId || 'goal-1',
      category: newProj.category || 'Product Development',
      colorAccent: newProj.colorAccent || '#3525cd',
    };

    setProjects((prev) => [project, ...prev]);
    addToast({
      type: 'success',
      title: 'Project Created',
      message: `"${project.name}" has been added to your active projects.`,
    });
  };

  const addTask = (newTask: Partial<TaskItem> & { title: string; projectId: string }) => {
    const proj = projects.find((p) => p.id === newTask.projectId) || projects[0];
    const codeNum = Math.floor(120 + Math.random() * 880);
    const code = `${proj.code.split('-')[0]}-${codeNum}`;
    const assignee = teamMembers.find((m) => m.id === newTask.assigneeId) || currentUser;

    const task: TaskItem = {
      id: `task-${Date.now()}`,
      code,
      title: newTask.title,
      description: newTask.description || '',
      status: newTask.status || 'todo',
      priority: newTask.priority || 'medium',
      projectId: proj.id,
      projectName: proj.name,
      milestoneId: newTask.milestoneId || 'ms-3',
      milestoneName: newTask.milestoneName || 'Sprint 3 Target',
      assigneeId: assignee.id,
      assigneeName: assignee.name,
      assigneeAvatar: assignee.avatar,
      dueDate: newTask.dueDate || '2024-09-30',
      dueLabel: newTask.dueLabel || 'Due Sept 30',
      checklist: newTask.checklist || [],
      comments: [],
      attachmentCount: 0,
      createdAt: new Date().toISOString(),
    };

    setTasks((prev) => [task, ...prev]);

    // Add activity
    setActivities((prev) => [
      {
        id: `act-${Date.now()}`,
        userName: currentUser.name.split(' ')[0],
        userAvatar: currentUser.avatar,
        action: 'created task',
        target: task.title,
        category: 'New Task',
        timeAgo: 'Just now',
        timestamp: new Date().toISOString(),
      },
      ...prev,
    ]);

    addToast({
      type: 'success',
      title: 'Task Added',
      message: `Task ${task.code} was added to ${task.status.replace('_', ' ').toUpperCase()}.`,
    });
  };

  const updateTaskStatus = (taskId: string, status: TaskStatus) => {
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === taskId) {
          const isDone = status === 'done';
          return {
            ...t,
            status,
            completedAt: isDone ? new Date().toISOString() : undefined,
          };
        }
        return t;
      })
    );

    const task = tasks.find((t) => t.id === taskId);
    if (task) {
      if (status === 'done') {
        setActivities((prev) => [
          {
            id: `act-${Date.now()}`,
            userName: currentUser.name.split(' ')[0],
            userAvatar: currentUser.avatar,
            action: 'completed',
            target: task.title,
            category: 'Completed',
            timeAgo: 'Just now',
            timestamp: new Date().toISOString(),
          },
          ...prev,
        ]);
      }

      addToast({
        type: 'info',
        title: 'Status Updated',
        message: `${task.code} is now ${status.replace('_', ' ').toUpperCase()}`,
      });
    }
  };

  const toggleTaskChecklist = (taskId: string, checklistId: string) => {
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === taskId) {
          const updatedChecklist = t.checklist.map((item) =>
            item.id === checklistId ? { ...item, completed: !item.completed } : item
          );
          return { ...t, checklist: updatedChecklist };
        }
        return t;
      })
    );
  };

  const addTaskComment = (taskId: string, content: string) => {
    if (!content.trim()) return;

    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === taskId) {
          const newComment = {
            id: `comment-${Date.now()}`,
            authorId: currentUser.id,
            authorName: currentUser.name,
            authorAvatar: currentUser.avatar,
            createdAt: 'Just now',
            content: content.trim(),
          };
          return {
            ...t,
            comments: [...t.comments, newComment],
          };
        }
        return t;
      })
    );

    addToast({
      type: 'success',
      title: 'Comment Posted',
      message: 'Your comment was added to the task thread.',
    });
  };

  const addGoal = (newGoal: Partial<CompanyGoal> & { title: string; keyResult: string }) => {
    const goal: CompanyGoal = {
      id: `goal-${Date.now()}`,
      goalNumber: goals.length + 1,
      title: newGoal.title,
      keyResult: newGoal.keyResult,
      ownerName: newGoal.ownerName || currentUser.name,
      ownerRole: newGoal.ownerRole || currentUser.role,
      deadline: newGoal.deadline || 'Dec 31, 2024',
      status: 'On Track',
      velocityPercentage: 0,
      milestonesScoped: 0,
      totalMilestones: 4,
      quarter: newGoal.quarter || 'Q4 2024',
      projectIds: newGoal.projectIds || [selectedProjectId],
    };

    setGoals((prev) => [...prev, goal]);
    addToast({
      type: 'success',
      title: 'Goal Established',
      message: `Goal #${goal.goalNumber} added to workspace roadmap.`,
    });
  };

  const addMilestone = (newMs: Partial<Milestone> & { title: string; projectId: string }) => {
    const ms: Milestone = {
      id: `ms-${Date.now()}`,
      number: milestones.length + 1,
      title: newMs.title,
      description: newMs.description || '',
      projectId: newMs.projectId || selectedProjectId,
      status: 'pending',
      progressPercentage: 0,
      ownerName: newMs.ownerName || currentUser.name,
      ownerRole: newMs.ownerRole || currentUser.role,
      ownerInitials: newMs.ownerInitials || currentUser.initials,
      deadline: newMs.deadline || 'Oct 25, 2024',
      tasksCount: 0,
      completedTasksCount: 0,
    };

    setMilestones((prev) => [...prev, ms]);
    addToast({
      type: 'success',
      title: 'Milestone Created',
      message: `Milestone "${ms.title}" sequenced into the roadmap.`,
    });
  };

  const sendMessage = (channelId: string, content: string) => {
    if (!content.trim()) return;

    const newMsg: MessageItem = {
      id: `msg-${Date.now()}`,
      channelId,
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderAvatar: currentUser.avatar,
      senderRole: currentUser.role,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      content: content.trim(),
    };

    setMessages((prev) => [...prev, newMsg]);
  };

  const markNotificationAsRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  };

  const markAllNotificationsAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
    addToast({
      type: 'info',
      title: 'All Caught Up',
      message: 'All notifications marked as read.',
    });
  };

  const addFile = (newFile: Partial<FileItem> & { name: string; size: string }) => {
    const proj = projects.find((p) => p.id === newFile.projectId) || projects[0];
    const file: FileItem = {
      id: `file-${Date.now()}`,
      name: newFile.name,
      type: newFile.type || 'pdf',
      size: newFile.size,
      modifiedDate: 'Just now',
      projectId: proj.id,
      projectName: proj.name,
      ownerName: currentUser.name,
      category: newFile.category || 'Sprint Assets',
    };

    setFiles((prev) => [file, ...prev]);

    // Add activity
    setActivities((prev) => [
      {
        id: `act-${Date.now()}`,
        userName: currentUser.name.split(' ')[0],
        userAvatar: currentUser.avatar,
        action: 'uploaded',
        target: file.name,
        category: 'Attachment',
        timeAgo: 'Just now',
        timestamp: new Date().toISOString(),
      },
      ...prev,
    ]);

    addToast({
      type: 'success',
      title: 'File Uploaded',
      message: `"${file.name}" uploaded successfully.`,
    });
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        currentView,
        setCurrentView,
        selectedProjectId,
        setSelectedProjectId,
        selectedTaskId,
        setSelectedTaskId,
        openTaskDetails,
        closeTaskDetails,
        openProjectDetails,
        projects,
        tasks,
        goals,
        milestones,
        teamMembers,
        files,
        messages,
        notifications,
        activities,
        toasts,
        isCommandPaletteOpen,
        setIsCommandPaletteOpen,
        isCreateItemModalOpen,
        setIsCreateItemModalOpen,
        createItemDefaultTab,
        setCreateItemDefaultTab,
        openCreateModal,
        searchQuery,
        setSearchQuery,
        addToast,
        removeToast,
        addProject,
        addTask,
        updateTaskStatus,
        toggleTaskChecklist,
        addTaskComment,
        addGoal,
        addMilestone,
        sendMessage,
        markNotificationAsRead,
        markAllNotificationsAsRead,
        addFile,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = (): AppContextType => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
